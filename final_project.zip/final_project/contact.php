<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <?php
         include 'header.php';
        ?>
        
        <div class="container" style="margin-top:5%">
            <div class="row">
                
                
                <div class="col-lg-3 col-xs-10" >
                    <br>
                      <img src="http://jksafelogistics.com/images/care2.jpg" alt="live support" class="img-responsive">
                </div>
                
                <div class="col-lg-9 col-xs-10 col-xs-offset-1 col-md-offset-0" >
                    <h3> LIVE SUPPORT </h3>
                    <br>
                    <h5>24 hours | 7 days a week | 365 days a year Live Technical Support</h5>
                    <p class="text-justify">A customer support is a range of customer services to assist customers in making 
                        cost effective and correct use of a product.[4] It includes assistance in planning, installation, training,
                        trouble shooting, maintenance, upgrading, and disposal of a product.[4] These services even may be done at 
                        customer's side where he/she uses the product or service. In this case it is called "at home customer services" or "at home customer support".
                        Regarding technology products such as mobile phones, televisions, computers, software products or other 
                        electronic or mechanical goods, it is termed technical support.</p>
                    
                </div>
        </div>
            <br><br>
            
            <div class="row">
                
                
                <div class="col-lg-7 col-xs-10" >
                    <br>
                      <div class="panel">
                          <div class="panel-heading">
                              <h3>CONTACT US</h3>
                          </div>
                          <div class="panel-body">
                              <form action="contact_script.php" method="post">
                                    <p>Name:
                                        <input type="name" name="name" class="form-control" required>
                                    <p>Email:
                                        <input type="email" name="email" class="form-control" required> 
                                    <p>Message:
                                        <textarea type="text" name="msg" class="form-control" required></textarea>
                                    <br>    
                                        <button class="btn btn-primary">Submit</button>   
                              </form>
                                  
                          </div>
                      </div>
                </div>
                
                <div class="col-lg-4 col-xs-10 col-xs-offset-1 col-md-offset-0" >
                    <br> 
                    <h3> Company Information</h3>
                    <p>
                        500 Lorem Ipsum Dollar Sit<br>
                        22-56-2-9 St. Amet Lorem<br>
                        USA<br>
                        Phone :(00)222 666 444<br>
                        Fax : (000)000 00 00 0<br>
                        Email : info@mycompany.com<br> 
                        Follow on : facebook,twitter<br>
                    </p>
                    
                </div>
        </div>
        </div>
        <?php
        include 'footer.php';
        ?>
        
    </body>
</html>


