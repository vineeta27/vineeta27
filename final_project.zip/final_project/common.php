<?php
$con=mysqli_connect("localhost","root","","e-store");
session_start();
?>