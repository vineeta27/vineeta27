<?php
include 'common.php';

$name= mysqli_real_escape_string($con,$_POST['name']);
$email=  mysqli_real_escape_string($con,$_POST['email']);
$password= md5(mysqli_real_escape_string($con,$_POST['password']));
$contact=  mysqli_real_escape_string($con,$_POST['contact']);
$city=  mysqli_real_escape_string($con,$_POST['city']);
$address=  mysqli_real_escape_string($con,$_POST['address']);
$regex_email="/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
if(!preg_match($regex_email,$email))
{
    echo "incorrect email";
}

$select_query="select email,u_id from user where email='$email'";
$query_result=mysqli_query($con,$select_query) or die(mysqli_error($con));
if(mysqli_num_rows($query_result)>0)
{
    $_SESSION['a']=1;
     header('location:login.php');
}
else
{
$user_registration_query= "insert into user(name, email, password, contact, city, address) values ('$name','$email','$password', '$contact', '$city', '$address')";

$user_registration_submit=mysqli_query($con,$user_registration_query) or die(mysqli_error($con));
$_SESSION['email']=$email;
header('location:index.php');
}
?>
