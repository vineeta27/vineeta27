<?php

include 'common.php';

$name= mysqli_real_escape_string($con,$_POST['name']);
$email=  mysqli_real_escape_string($con,$_POST['email']);
$msg=  mysqli_real_escape_string($con,$_POST['msg']);

 $user_registration_query= "insert into enquiry(e_name, e_email,message) values ('$name','$email','$msg')";
 $user_registration_submit=mysqli_query($con,$user_registration_query) or die(mysqli_error($con));
 header('location:contact.php');
  
?>



