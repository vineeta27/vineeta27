<?php
function check_if_added_to_cart($item_id)
{
 
  $con=mysqli_connect("localhost","root","","e-store");
  $user_email=$_SESSION['email'];
  $check_query="SELECT u_id FROM user WHERE email='$user_email'";
  $result_query= mysqli_query($con,$check_query);
  $user1_id= mysqli_fetch_array($result_query);
  $user_id=$user1_id['u_id'];
  $product_select_query="SELECT * FROM user_item WHERE item_id='$item_id' AND user_id='$user_id' AND status='Added to cart'";
  $product_query_result=mysqli_query($con,$product_select_query)or die(mysqli_error($con));
  if(mysqli_num_rows($product_query_result)>=1)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}
?>

