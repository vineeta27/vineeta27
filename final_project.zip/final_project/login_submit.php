<?php
include 'common.php';
$email=  mysqli_real_escape_string($con,$_POST['email']);
$password= md5(mysqli_real_escape_string($con,$_POST['password'])); 
$select_query="select u_id,email,password from user";
$select_query_result=mysqli_query($con,$select_query);
$row= mysqli_fetch_array($select_query_result);

if( $row['email']!=$email )
{
    $_SESSION['b']=1;
    header('location:signup.php');
}
 else {
    
    if ($row['password']!=$password)
            {
                $_SESSION['c']=1;
                header('location:login.php');
            }
    else
        {
                mysqli_fetch_array($select_query_result);
                $_SESSION['email']=$email;
                header('location:index.php');
        }
}
?>