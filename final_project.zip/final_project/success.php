<?php

include 'common.php';
if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }
 
$user_email=$_SESSION['email'];
$select_query="SELECT u_id FROM user WHERE email='$user_email'";
$check_query= mysqli_query($con,$select_query);
$user1_id= mysqli_fetch_array($check_query);
$user_id=$user1_id['u_id'];
$update_query="UPDATE user_item SET status='Confirmed' WHERE user_id='$user_id'";
$update_result_query = mysqli_query($con,$update_query)or die(mysqli_error($con));
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
        <?php
        include 'header.php';
        ?>
        <div class="alert alert-success msg">
            <strong>Successful!</strong>Your order is confirmed.Thank you for shopping with us.
            <br>
            <p><a href="index.php">Click Here</a> to purchase any other item.</p>
        </div>
        <!--footer-->
        
        <?php
       if(!isset($_SESSION['email']))
            {
                  include 'footer.php';            
            }
        ?>
    </body>
</html>

        