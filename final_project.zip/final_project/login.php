<?php
include 'common.php';
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <?php
         include 'header.php';
         if(isset($_SESSION['a']))
                {
             ?>
         
                      <div class="alert alert-danger msg">
                            <strong>Alert!</strong>Account already exist, Please login to continue.
                      </div>
         <?php
                        unset($_SESSION['a']);
                }
          if(isset($_SESSION['c']))
                {
             ?>
         
                      <div class="alert alert-danger msg">
                            <strong>Alert!</strong>You entered wrong password!!
                      </div>
         <?php 
                       unset($_SESSION['c']);
                }
           
        ?>
        <div class="container">
        <div class= "panel panel-default" id="form">
            <div class="panel-heading">
                <h2> LOGIN</h2>
                <hr>
            </div>
            <div class="panel-body">
                <p>Don't have an account? <a href='signup.php'>Register</a></p>
                <br>
                <form method="post" action="login_submit.php">
                    <div class="form-group">
                        <input class="form-control" placeholder="Enter email" name="email" type="email" required>
                        <input class="form-control" placeholder="Enter password" name="password" type="password" required>
                    </div>
                    <button class="btn btn-primary">LOGIN</button>
                </form>
                
            </div>
            <div class="panel-footer">
                <a href='change.php'>Forgot Password?</a>
            </div>
            
        </div>
        </div>
            <?php
         include 'footer.php';
        ?> 
    </body>
</html>

