<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <?php
         include 'header.php';
        ?>
        
        <div class="container" style="margin-top:5%">
            <div class="row">
                <div class="col-lg-5 col-xs-10 col-xs-offset-1 col-md-offset-0" >
                    <h4> WHO WE ARE</h4>
                    <br>
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhBCBZY5oVniKOQYHEwijXK6-rdy2p-5y9IlohEkdmNG1MCAOmmA" alt="ABOUT US" class="img-responsive">
                    <p class="text-justify">Mobile commerce is worth US$230 billion, with Asia representing almost half of the market, 
                        and has been forecast to reach US$700 billion in 2017.[2] According to BI Intelligence[3] in 
                        January 2013, 29% of mobile users have now made a purchase with their phones. Walmart estimated[4]
                        that 40% of all visits to their internet shopping site in December 2012 was from a mobile device.
                        Bank of America predicts[5] $67.1 billion in purchases will be made from mobile devices by European 
                        and U.S. shoppers in 2015. m-Commerce made up 11.6 per cent of total e-commerce spending in 2014,
                        and is forecast to increase to 45 per cent by 2020, according to BI Intelligence. ComScore reported
                        in February 2017 that mobile commerce had grown 45% in year to December 2016.</p>
                    
                </div>
                
                <div class="col-lg-5 col-xs-10 col-xs-offset-1" >
                    <h4> OUR HISTORY</h4>
                    <br>   
                    <p class="text-justify">The Global Mobile Commerce Forum, which came to include over 100 organisations, 
                        had its fully minuted launch in London on 10 November 1997. Kevin Duffey was elected as the Executive
                        Chairman at the first meeting in November 1997. The meeting was opened by Dr Mike Short, former chairman
                        of the GSM Association, with the very first forecasts for mobile commerce from Kevin Duffey (Group Telecoms
                        Director of Logica) and Tom Alexander (later CEO of Virgin Mobile and then of Orange). Over 100 companies
                        joined the Forum within a year, many forming mobile commerce teams of their own, e.g. MasterCard and Motorola
                        . Of these one hundred companies, the first two were Logica and Cellnet (which later became O2).
                        Member organisations such as Nokia, Apple, Alcatel, and Vodafone began a series of trials and collaborations
                        Mobile commerce services were first delivered in 1997, when the first two mobile-phone enabled Coca-Cola 
                        vending machines were installed in the Helsinki area in Finland. The machines accepted payment via SMS 
                        text messages. This work evolved to several new mobile applications such as the first mobile phone-based 
                        banking service was launched in 1997 by Merita Bank of Finland, also using SMS. Finnair mobile check-in was
                        also a major milestone, first introduced in 2001.[6]The m-Commerce(tm) server developed in late 1997 by
                        Kevin Duffey and Andrew Tobin at Logica won the 1998 Financial Times award for "most innovative mobile 
                        product," in a solution implemented with De La Rue, Motorola and Logica.[7] The Financial Times commended 
                        the solution for "turning mobile commerce into a reality."[citation needed] The trademark for m-Commerce 
                        was filed on 7 April 2008.[8]</p>
                    
                </div>
        </div>
        </div>
        <?php
        include 'footer.php';
        ?>
        
    </body>
</html>
