<?php
$item_id=$_GET['id'];
include 'common.php';
$user_email=$_SESSION['email'];
$select_query="SELECT u_id FROM user WHERE email='$user_email'";
$check_query= mysqli_query($con,$select_query);
$user1_id= mysqli_fetch_array($check_query);
$user_id=$user1_id['u_id'];
$delete_query="DELETE FROM user_item WHERE user_id='$user_id' AND item_id='$item_id'";
$delete_result_query = mysqli_query($con,$delete_query)or die(mysqli_error($con));
header('location:cart.php');

?>
