<?php
 include 'common.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <title>E-Store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
         <?php
          include 'header.php';
          include 'check-if-added.php';
         ?>
          
        <br><br><br><br>
        <div class="container">
             <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="http://sm.pcmag.com/t/pcmag_ap/photo/default/samsung-s7-black-pearl-01_zgt3.640.jpg" alt="Samsung s7 edge">
                        <div class="caption">
                            <h3>Samsung S7 Edge</h3>
                            <p>Price: Rs.53,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(1))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=1">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgN6HoeG-bBzDIUaEn-kG36yYGq_1qOqwW8gTfk8R6ijRSzlvE" alt="camera">
                        <div class="caption">
                            <h3>BlackBerry Motion</h3>
                            
                        </div>
                        <p>Price: Rs.40,000.00</p>
                            <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(2))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=2">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="http://data1.ibtimes.co.in/cache-img-0-450/en/full/600431/imgwhen-will-xiaomi-redmi-note-3-mi-5-be-available-again-sale-details-not-listed-amazon-mi-com.jpg" alt="camera">
                        <div class="caption">
                            <h3>Redmi Note 3</h3>
                            <p>Price: Rs.45,000.00
                                
                        </div>
                        <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(3))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=3">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://blenderartists.org/forum/attachment.php?attachmentid=462701&d=1480867795&thumb=1" alt="camera">
                        <div class="caption">
                            <h3>iPhone 7</h3>
                            <p>Price: Rs.90,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(4))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=4">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?> 
                    </div>
                </div>
                
            </div>
            
             <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="http://technave.com/data/files/mall/article/201404171157149566.jpg" alt="watch">
                        <div class="caption">
                            <h3>Oppo N1</h3>
                            <p>Price: Rs.30,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(5))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=5">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="http://images.indianexpress.com/2017/06/sonyxperiaxzpremium_big_1.jpg" alt="watch">
                        <div class="caption">
                            <h3>Sony Xperia XZ</h3>
                            <p>Price: Rs.25,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(6))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=6">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://i.pinimg.com/736x/9e/16/45/9e164503dfc341bf8e8698be186901e3--lenovo-smartphones-mobile-smartphone.jpg" alt="watch">
                        <div class="caption">
                            <h3>Moto Z</h3>
                            <p>Price: Rs.22,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(7))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=7">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>    
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="http://theinfobox.net/wp-content/uploads/2016/12/Gionee-M2017-.jpg" alt="watch">
                        <div class="caption">
                            <h3>Gionee M2017 </h3>
                            <p>Price: Rs.18,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(8))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=8">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                
            </div>
             <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="http://images.deccanchronicle.com/dc-Cover-u560otisruufjlejhemu2glta4-20170416151918.Medi.jpeg" alt="camera">
                        <div class="caption">
                            <h3>Nokia 9</h3>
                            <p>Price: Rs.40,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(9))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=9">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="https://image01.oneplus.net/shop/201706/20/964/3a74c634fa4e301594aa0bda61625a98.jpg" alt="camera">
                        <div class="caption">
                            <h3>OnePlus 5</h3>
                            <p>Price: Rs.30,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(10))
                                  {
                                      ?>
                                 <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=10">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://i1.wp.com/www.xiaomimi6phone.com/wp-content/uploads/2017/01/Xiaomi-Redmi-Note-5.jpg" alt="camera">
                        <div class="caption">
                            <h3>Redmi Note 5</h3>
                            <p>Price: Rs.20,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(11))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=11">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://boygeniusreport.files.wordpress.com/2017/06/google-pixel-2-concept.jpg?quality=98&strip=all" alt="camera">
                        <div class="caption">
                            <h3>Google pixel 2</h3>
                            <p>Price: Rs.60,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(12))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=12">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                
            </div>
            
        </div>
        <!--footer-->
        
        <?php
       if(!isset($_SESSION['email']))
            {
                  include 'footer.php';            
            }
        ?>
        
    </body>
</html>

