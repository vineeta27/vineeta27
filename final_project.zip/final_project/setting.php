<?php
 include 'common.php';
 if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
        
          <?php
          include 'header.php';
          if(isset($_SESSION['d']))
                {
             ?>
         
                      <div class="alert alert-danger msg">
                            <strong>Alert!</strong>Password mis-matched!!
                      </div>
         <?php
                           unset($_SESSION['d']);
                }
                if(isset($_SESSION['e']))
                {
             ?>
         
                      <div class="alert alert-danger msg">
                            <strong>Alert!</strong>Entered wrong password!!
                      </div>
         <?php
                      unset($_SESSION['e']);
                }
          ?>
        <!-- login panel -->
        
      
        
        <div class="container">
            <div class="panel" id="form"  >
            <div class="panel-heading">
                <h1>Change Password</h1>
            </div>
            <div class="panel-body">
                <form action="settings_script.php" method="post">
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="Old Password" name="old_password" required>
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="New password" name="new_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="Re-type New password" name="re_password" required>
                    </div>
                    <button class="btn btn-primary">Change</button>
                </form>
            </div>
        </div>
        </div>
        <!--footer-->
        
        <?php
          include 'footer.php';
        ?>
                
        
    </body>
</html>
