<?php

include 'common.php';
if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }


$old_password= md5(mysqli_real_escape_string($con,$_POST['old_password']));
$new_password=  md5(mysqli_real_escape_string($con,$_POST['new_password']));
$re_password=  md5(mysqli_real_escape_string($con,$_POST['re_password']));
if($new_password!=$re_password)
{
    $_SESSION['d']=1;
    header('location:setting.php');
}
else{
    $user_email=$_SESSION['email'];
    $select_query="SELECT u_id FROM user WHERE email='$user_email'";
    $check_query= mysqli_query($con,$select_query);
    $user1_id= mysqli_fetch_array($check_query);
    $user_id=$user1_id['u_id'];   
    $select_pwd_query="SELECT password FROM user WHERE u_id='$user_id'";
    $result_pwd_query= mysqli_query($con, $select_pwd_query);
    $pwd_result= mysqli_fetch_array($result_pwd_query);
    if($old_password==$pwd_result['password'])
    {
        $update_pwd_query="UPDATE user SET password='$new_password' WHERE u_id='$user_id'";
       $update_result_query = mysqli_query($con,$update_pwd_query)or die(mysqli_error($con));
       session_destroy();
       header('location:login.php');  
    }
    else{
        $_SESSION['e']=1;
        header('location:setting.php');
    }
}
?>

