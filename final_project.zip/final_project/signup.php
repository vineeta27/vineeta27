<?php
 include 'common.php';
 if(isset($_SESSION['email']))
 {
       header('location:index.php');
 }
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>e-store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="description" content="Best Online shopping website.Latest smartphones available.">
        <meta name="author" content="Vineeta Suthar">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <?php
         include 'header.php';
         if(isset($_SESSION['b']))
                {
             ?>
         
                      <div class="alert alert-danger msg">
                            <strong>Alert!</strong>Account doesn't exist, Please signup to continue.
                      </div>
         <?php
               unset($_SESSION['b']);
                }
        ?>
        
        <div class="container" style="margin-top:4%">
        <div class="row">
            <div class="col-lg-5 col-xs-10">
              
                <img style="margin-top: 25%" src="https://cavall.io/assets/signup-mascot-4f6b60edd6ac4ef6c50589e55946f556631831ee70881722ec81d3b8a127195c.png" alt="signup" class="img-responsive">
               
            </div>
            
            <div class="col-lg-5 col-xs-10 col-xs-offset-1">
                       <div class= "panel">
                            <div class="panel-heading">
                                <h3> SIGN UP</h3>
                            </div>
                            <div class="panel-body">
                                <form method="post" action="signup_script.php">
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Name" name="name" type="text" required><br>
                                        <input class="form-control" placeholder="Email" name="email" type="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required><br>
                                        <input class="form-control" placeholder="Password" name="password" type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required><br>
                                        <input class="form-control" placeholder="Contact" name="contact" type="number"   required><br>
                                        <input class="form-control" placeholder="City" name="city" type="text" required><br>
                                        <textarea class="form-control" placeholder="Address" name="address" required></textarea>
                                    </div>
                                    <button class="btn btn-primary">Submit</button>
                                </form>

                            </div>
                           
                       </div>
            </div>
        </div>
        </div>
  
            <?php
         include 'footer.php';
        ?> 
    </body>
</html>



