<div class="container-fluid" style="background-color:black ;color:white; margin-top: 4%; padding:1%">
    <div class="row">
        <div class="col-md-3 col-xs-10 col-xs-offset-2 col-md-offset-1">
            <h4>Information</h4>
            <div class="row">
                <div class="col-xs-10 ">
                    <a style="color:white" href="about.php">About Us</a>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-10">
                    <a style="color:white" href="contact.php">Contact Us</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-xs-10 col-xs-offset-2 col-md-offset-1">
            <h4>My Account</h4>
                <div class="row">
                    <div class="col-xs-10">
                        <a style="color:white" href="login.php">Login</a>
                    </div>
                </div>
            <div class="row">
                <div class="col-xs-10">
                    <a style="color:white" href="signup.php">Signup</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-xs-10 col-xs-offset-2 col-md-offset-1">
            <h4>Contact Us</h4>
            <div class="row">
                <div class="col-xs-10">
                    <h6>Contact: +91 9876543211</h6>
                </div>
           </div>
        </div>
    </div>
     
    
</div>

