<?php
 include 'common.php';
 if(isset($_SESSION['email']))
 {
       header('location:product.php');
 }
 ?>
<!DOCTYPE html>

<html>
    <head>
        <title>Lifestyle Store Sign Up</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
        <?php
         include 'header.php';
        ?>
        
        <!-- login panel -->
        <div class="container">
        <div class="panel panel-primary" id="form" >
            <div class="panel-heading">
                <h1>SIGN UP</h1>
            </div>
            <div class="panel-body">
                <form method="post" action="signup_script.php">
                    <div class="form-group ">
                        <input class="form-control" type="text" placeholder="Name" name="name">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="email" placeholder="Enter email address" name="email">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="Enter password" name="password" pattern=".{6,}">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="number" placeholder="Enter contact no." name="contact" pattern=".{10,10}">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="text" placeholder="Enter city" name="city">
                    </div>
                    <div class="form-group ">
                        <textarea class="form-control" placeholder="Enter address" name="address" rows="2"></textarea>
                    </div>
                    
                    <button class="btn btn-primary">SIGN UP</button>
                </form>
            </div>
            <div class="panel-footer">
                <p>Already have an account?<a href='login.php'>Login</a></p>
            </div>
                
        </div>
        </div>
         
        <!--footer-->
        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>

