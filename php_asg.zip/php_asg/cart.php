<?php
 include 'common.php';
 if(!isset($_SESSION['email']))
 {
       header('location:login.php');
 }
 ?>

<!DOCTYPE html>

<html>
    <head>
        <title>Lifestyle Store Products</title>
        
         <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <?php
        include 'header.php';
        ?>
            
        <!--navigation bar-->
         <div class="tab">
          <table class=" table table-bordered table-striped table-responsive">
              <tr> 
                  <th>Itemu Number</th>
                  <th>Item Name</th>
                  <th>Price</th>
                  <th> </th>
              </tr>
        
      <?php
            $user_email=$_SESSION['email'];
            $check_query="SELECT id FROM users WHERE email='$user_email'";
            $result_query= mysqli_query($con,$check_query);
            $user1_id= mysqli_fetch_array($result_query);
            $user_id=$user1_id['id'];
            $select_item_query="SELECT * FROM items INNER JOIN users_items ON items.i_id=users_items.item_id WHERE users_items.user_id='$user_id';";
            $item_query_result=mysqli_query($con,$select_item_query)or die(mysqli_error($con));
           
           if(mysqli_num_rows($item_query_result)==0)
           {
               echo "Add items to the cart first";
               header('location:product.php');
           }
           else
                 {
               $sum=0;
               $count=0;
               $item_array=array(100);
               $i=0;
               while($var=mysqli_fetch_array($item_query_result))
               {
                 $sum=$sum + $var['price'];
                 $count=$count+1;
                  $item_array[$i]=$var['i_id'];
                  $i=$i+1;
              
                ?>
              <tr>
                   
                  <td> <?php echo $count ?> </td>
                    <td> <?php echo $var['name'] ?> </td>
                    <td> <?php echo $var['price'] ?> </td>
                    <td> <a href="cart-remove.php?id=<?php echo $var['i_id']?>" class="remove_item_link">Remove</a> </td>
              </tr>
              <?php
               }
              ?>
              <tr>
                  <td> </td>
                  <td> Total</td>
               <td> Rs.<?php echo $sum ?> /-</td>
                 <?php echo $var['i_id']?>
                  <td><a href="success.php?id=<?php
                    foreach($item_array as $arr)
                    {
                      echo $arr ;
                    }  
                    ?>" class="btn btn-primary">Confirm Order</a></td>
              </tr>
              
          </table>
         </div>
        <?php 
             }
        ?>
         <!--footer-->
        
        <?php
         include 'footer.php';
        ?>
    </body>
</html>
  
