<?php

include 'common.php';
if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }
 
$user_email=$_SESSION['email'];
$select_query="SELECT id FROM users WHERE email='$user_email'";
$check_query= mysqli_query($con,$select_query);
$user1_id= mysqli_fetch_array($check_query);
$user_id=$user1_id['id'];
$update_query="UPDATE users_items SET status='Confirmed' WHERE user_id='$user_id'";
$update_result_query = mysqli_query($con,$update_query)or die(mysqli_error($con));
?>
<!DOCTYPE html>

<html>
    <head>
         <title>Lifestyle Store Products</title>
        
         <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
        <?php
        include 'header.php';
        ?>
        <div class="alert alert-success msg">
            <strong>Successful!</strong>Your order is confirmed.Thank you for shopping with us.
            <br>
            <p><a href="product.php">Click Here</a> to purchase any other item.</p>
        </div>
        <!--footer-->
        
        <?php
        include 'footer.php';
        ?>
    </body>
</html>

        