<?php

include 'common.php';
if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }


?>

<!DOCTYPE html>

<html>
    <head>
       <title>Lifestyle Store Products</title>
         <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
        
          <?php
          include 'header.php';
          ?>
        <!-- login panel -->
        
      
        
        <div class="container">
        <div class="panel panel-primary set"  >
            <div class="panel-heading">
                <h1>Change Password</h1>
            </div>
            <div class="panel-body">
                <form action="settings_script.php" method="post">
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="Old Password" name="old_password" id="old_pwd">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="New password" name="new_password" id="new_pwd">
                    </div>
                    <div class="form-group ">
                        <input class="form-control" type="password" placeholder="Re-type New password" name="re_password" id="re_pwd">
                    </div>
                    <button class="btn btn-primary">Change</button>
                </form>
            </div>
        </div>
        </div>
        <!--footer-->
        
        <?php
          include 'footer.php';
        ?>
                
        
    </body>
</html>
