<?php
function check_if_added_to_cart($item_id)
{
  $con=mysqli_connect("localhost","root","","store");
  $user_email=$_SESSION['email'];
  $check_query="SELECT id FROM users WHERE email='$user_email'";
  $result_query= mysqli_query($con,$check_query);
  $user1_id= mysqli_fetch_array($result_query);
  $user_id=$user1_id['id'];
  $product_select_query="SELECT * FROM users_items WHERE item_id='$item_id' AND user_id='$user_id' AND status='Addede to cart'";
  $product_query_result=mysqli_query($con,$product_select_query)or die(mysqli_error($con));
  if(mysqli_num_rows($product_query_result)>=1)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}
?>

