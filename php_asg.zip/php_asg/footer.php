 <!-- footer-->
        <footer id="footer">
        <div class="container-fluid">
            <center>
                <p>Copyright @ Lifestyle Store.All Rights Reserved | Contact Us: +91 90000 00000 </p>
            </center>
        </div>
  </footer>

