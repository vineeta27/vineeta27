<?php

$item_id=$_GET['id'];
include 'common.php';
$user_email=$_SESSION['email'];
$select_query="SELECT id FROM users WHERE email='$user_email'";
$check_query= mysqli_query($con,$select_query);
$user1_id= mysqli_fetch_array($check_query);
$user_id=$user1_id['id'];
$insert_query="INSERT INTO users_items(user_id,item_id,status) VALUES ('$user_id','$item_id','Addede to cart')";
$cart_result_query = mysqli_query($con,$insert_query)or die(mysqli_error($con));
header('location:product.php');
?>

