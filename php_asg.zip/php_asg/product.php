<?php
 include 'common.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Lifestyle Store Products</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--navigation bar-->
         <?php
          include 'header.php';
          include 'check-if-added.php';
         ?>
          
        <br><br><br><br>
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our Lifestyle Store!</h1>
                <p>We have the best cameras,watches and smartphones for you.No need to hunt around,we have all in one place.</p>
            </div>
          
            <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="https://rukminim1.flixcart.com/image/704/704/camera/g/w/e/canon-eos-6d-kit-24-105-slr-original-imadqbqmuab8jhs3.jpeg?q=70" alt="camera">
                        <div class="caption">
                            <h3>Canon EOS</h3>
                            <p>Price: Rs.36,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(1))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=1">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="https://cnet1.cbsistatic.com/img/mixfLY5CYH9Uhng-p037fmKIhu4=/770x433/2014/02/06/22d872fb-a380-11e3-a24e-d4ae52e62bcc/35829202.jpg" alt="camera">
                        <div class="caption">
                            <h3>Sony DSLR</h3>
                            
                        </div>
                        <p>Price: Rs.40,000.00</p>
                            <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(2))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=2">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQRRrJ5qM0espqNZXknd8A1MO1CdqxQdm4S-vin3b7PALPJ1ox" alt="camera">
                        <div class="caption">
                            <h3>Nikon d810</h3>
                            <p>Price: Rs.45,000.00
                                
                        </div>
                        <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(3))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=3">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>
                      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="http://www.togtech.com/wp-content/uploads/2012/01/Olympus-OM-1.jpg" alt="camera">
                        <div class="caption">
                            <h3>Olympus</h3>
                            <p>Price: Rs.60,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(4))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=4">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?> 
                    </div>
                </div>
                
            </div>
            
             <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="http://www.fototime.com/8F3C4933EDFC256/orig.jpg" alt="watch">
                        <div class="caption">
                            <h3>Titan model #301</h3>
                            <p>Price: Rs.13,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(5))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=5">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExMWFRUXGB0bGRgYGCAbGxsYHRcaGBofHyAeHSggGh0lHxgaITEjJSkrLi4uICAzODMtNygtLisBCgoKDg0OGhAQGi0lICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMABBgMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAFBgMEBwIBAAj/xABCEAACAQIEBAUBBQcCBAYDAQABAhEDIQAEEjEFIkFRBhMyYXGBI0JSkaEHFGKxwdHwkuEkM0NyFVOCstLxY6LCFv/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACURAAICAgICAQQDAAAAAAAAAAABAhEDIRIxBEEiE1FxkQWB0f/aAAwDAQACEQMRAD8A0sm11/LHgZImY+cBuNcXqZdSXQCfTfc4R874mr1SsmFB2HU/1wT8qKdRVlw8WTVvRqcdoOOKjhfVb3OF/g/EKlZF+y0sBd25R9BgwnDTIZqhcgfeuPoMdSaas5ZJp0TpoYSDbHX7sOhxTrZqqHCLQ1L+IECPoceV1/FUdPaLfphLYNUW1y/8U48OWM48yOUpj0vr+Wx7xXiFOgoLm5MKo3Y9hhhR4KZ2jA7M8UpBjTDqGG8XjH1OjXzDq7VAlMEzTU7+xPfBWjk6aTppqJ3IG+AKBlHN0LEsSw6kH+2LaZqkbeYPrbF+R2xA1BCJYKR7gYQyPN5ilSptVqOoRRJM7DCHU/azlNZVKVR1H3xEH8zOKvi/gz5yt5aVkUdEDQI7teMLub/ZxmaekFqegn0oSWf/AGxD5N6NYqCWzS8nxs52nqyzeXT+9UbcdwB39zi7wzhalQzkveQTufcnAjgHA2o0VpstOjTmWQbsfc4ZKecpkhUO3bb4xZm69FyPgY8k9scGqceeYMBJMPjH0+2I/NGOTVnYxgGSs/tj3VPTEGs9Dj3W3scAE5jHhUd8VqlRuwxwKjfhwCLIpDucfaR3xTq5oKCz8qjqdsQ5bPJU9DTA3ggfrgAvtSB648aiDioCxNjbH3NvOGInqZQd8RnhiE7DHsNExfELmoL2+hwAetwlDuq/S2In4FTPUr8MR/XHaVmI3M4lRjAJN+tsMRWTgsbVH/1f3x9i5q+v0x7gHQp+LuH1aza69R1MhUpqo03PRu+LHCPCFOkoeo5JG2k2Ht7n3wfzuYp/vdOmxBIRmC9Adp/KccjhwJ1ITTvKjdT7x0nERxQjtI0llm1TZXynDeZiWbQY5Ce3X64MrUFgMVWZ19aah+JL/piXLZuk3oMntN5+MWZ2WVjrjsRjhh1G+BWXzdXMAgAU1kgv1aD9z++ENFnM16GopytU/Cu/1jb64VvF/hrM1wj0qi0yo2JLx30nphuyeUp0RppqFnfuT3J6nCd+07O10Wl5RKpJ1kT9JjClLirZUVbpFvwlXFFGTlMQTeL7NE+4xZzPG6mokEKOgjp9cZx4N4hmnq1tSFwAF1AWHWZ2ww501VXUUt1Mj++PH/kMvkSajiTS+6s9HxMWJJubX9hPM8YcyDU37WwPGeIjU5dR90tbChnePquoExHtue2Cnh7w8cyA9fOpTU3CUyNXwSdsc3j+P5cnfJr8s6cs/Hgqa/Q1ZjMHMqEy1FdYs0qCgHz3wX4bwg0VBZpqARO5+k7D4xX4Zwqvlqfl5arSqLMjzLN9SLH8sXFzNaYrZdh/Eh1j9L/pj34Rko1J2zxpzTfxVInWgJkyT/EZxbFHUNhH5YhyXlv1HwbEfngr5AjfFEFBsqgvpv8AOPHT+KMS5uFWYJ7DFGpmImQBHTABPToRNwZx41IiYGKFbNVQNYAAG8XwlftA8X+UqTrJVpprIValQD1NF/KpyOWxZvYHCboaVjHxjxF5RCU6b1nP3VGwmCTi1l+M02QMG0g7hrEHqI7jGM8P4bmuKZgfvFaozH/TTkcoA2XvAAgSTg34E4u9LMtksygerTL6WJMvFyOa5tzKeo+mJU90U4OrHTNeL252o0mdE3qMQq/rvgVwv9oD128vzaFJiYGqSfp0wm/tF8RirUajTMKLMqHlJ/qcAPD/AIbr5pwKa8oN2YwAOuM3kfLRqsUeOzbKXCSxmvUas0yLwv5bYMq2mwFu2BuT4cDTVVqGV5fe2CD5NwBYH69MdCOZkrZorJ5ccUs4rdB7xilVpGIek+9tJB/3x1l85v8AZVEA6kb4YgqKtuUH88ReYZi/1EjEVHOhrAj4JGLDMI9/Y4AI0md0P6HFmkh7D6HFIPqO1x7jHGqotwk+wN/7YYBSpU/hb6Y+wHTjjCQ1CsPgAjHmFQWAOELUr5qtXDAUdUa4BLaTdQZsJw9ZSrInFDK8LOlQmmmogBIi2CoplP8AbDbKJ9Ur2wrGvSpwao16mApVUIVjLRBMi4m+JeL+KKFCzVVBOwLASfjfGYcR42EzAqVlXS5LpTaQobYNo3P5CcTZXE0PPZjNeW65cHMUwY1M2lmE3CmLjpNsGF4rTFNTWK0YAGljEHt7/TGaZPxDnq2ry6VaosWCRQpgDtPMT7TixwTgX7yZzlStRI3TQUFzt5hksfg4LsfFLscKviyiJWkwLSY1MESB1lunwMK/FfFFOsxStmFdOtLKgt/qa5P0jBX/APweTp1Fq0qYqntWJcH3BJJBwXSs1PlOXWiNgQo0/RgLfXDSJbS6ELOeItC+Tl1q01/CKen9Wi+BOX4fWrloDggEy0t+mwONRqcFy9ZtdSKh9/6YKZDhlOn6F0+2JaT7GpV0ZNwnwHWrAGspDe9vy6DDFkv2eUlNywI740cgRzLPuMR1MtqFnI+N8TwjfRX1JAjh/AfKEhzH54NUqTDrOPLKbG5xNTqmMURZ61MHcA4q1cgs6gzof4WMfltiyb9DiGpmYJ2noCcAgRxatUyqNVfNIV6Col57DTcn6YVn8Y16uny8vTuCftD6yLQu0n64v8T8MtWq+dXru5+6AgVVEzABJEYrt4byv3g7GZhmgAzNgoA3xDWRvWkax+klvbA/iPx0aCUw9Icx5wjcoAgxcT32wi0snmc5XUka6zNyKLLSVmZxI73Old4uemCvio0XzBp0SXNM8x3RH/8A6YdtgfiC2+GuFpRWktNlavXKuakyU1BlYEyZch5I9h84yyzp0jXFi5Lk1om4RlaeUpCnTu7CXbrzICR8yWBPwMLnjvgRzFMZqjIr0hJ07souCIvqXcfl2wWqlUYiTfp/Uf2/niWhmSDGOa5Rls6uMZR0ZxX4a2fH71QULU9NZAfvhfUOoDQT8zixwPw1m1qKQxUDmPNAjrgnx3JfuOYXPUlJoVDFVFtpJ7dBJuJ2NuuNByD06tKlUSmvMJN9IMgEEH3x2Y+Mjz8qlF0L+VzGZpsClXUrXg74LNxxyfLNR0bvpOkn+mO+IcOossU+VxJWDJnc/TAPOZ+qtRVIdVUTzqZP5Y1qjFu3YTr8TriGPxqEkW6xi7w/xBXDaSvm05s4Ur+hwCyPiRms1MErtaLYM/8AjztTPOKR/wC0fTAFh+o1CJqoqztNpxG1TKWCtEdmIg/OEXN1qb+pxVK9ZO/WQcVzmVVR5Ogi8rMGD/PFWSaJl3DHka30YfnjzN5SqfTUVT2BIwi089VF/KjTuASDH8jiKh4grQSKbsAe+w97Xw7GPapmQLqG+HGPsLWW8UvU5CpLLcmwBH1O+PsFiGjxD4vo5aBOur92knM7fQYWOIcbzlRVGbenkKVSYv8AbMovtML0xGnG8tlGGX4blvOzLwCTzEMfxvf+cYlXwdmK1QZniDiswutJfQv/AMsTVm/Qv0M1Sq1hQ4dSUVNJY5iqNTEA3Kzvvvhn8P8AhulS56gFSqTLO/MxPsTt8YOZSktvLpCdrDYfzAxd/c2iSrBogXt8TikqJcrI1pkeix7xi9k6DbuxP+dsV8hTqgkVFUxcFf8Ae84u080eoEDczf8AKMJsSO8wWRfs6Ydug1Bf1xYy9Viv2ihT1WdQ/OMcllP+/wDl8etubxiRlWvwSkzB1HlVB95dj8jY4jzTV6UEUxVT7xU3jvp/ti9rnf8Az64m1gD++CxAvh3GKdUEA6XHqQ2ZbTcHE9SpqIAEnoZ/P4Hv/UgGpxDyapjyw9TYEcpB39QuBFz7dyQD1m82uWpqANdRzpRBY1H/AF0ou5P3R3JuxFnNZmlQQNVbrCi7Fm/Cqi7tt097YHPmc3X9AGVQ9WUVKxHxPl0/rqI/TEvDeEsX8+s3mVjbXHKi/gpj7qj8zucH8vlxtHMP1GKpLsnlekLS+FKTg+c1bME7mtVZvyUEIv8A6VGMg/aFwlaFbTlab05LA03CEEAepLaiLHefnH6GFRV5iQAOp7YwH9oXFKw4k9S0IxajK/8ATqU0FwRJBUCx2JOM5ulpFwtsTMtxXM0bqWpjug8sfnT0n9cNXCf2gVRC1jrHdhq6d1AcfJ8w72wCyee0imrIrLSSqii4P2gfmbfUVZ5FhsPnBnxP4coUPLQkK4yi1ahBu9ZiAEW8TuT/AAgnGamW4hROF5d/tMtFPWfSDNJ2gmEI2aJOmzAboMe5DMPROkyrLcdwd5Hb2OEtmr5J5FpC61YAghlDqtRO8EG9wdoInDZw3i1PNU7SrKLhjqZBNjqN6lOYGo8y7NNnbLLhUtrs6cGdx+Mui3xF2q1EcKSxI1Mvo3ud+SRup67EiMWEqxp1AifSentiklUpZhtvi54hzQZ/NX/lvGpexgSPpuPaPfGPyyXfaOh8cNNdMP8ABEWrUWk6h6b2dWEjTHNI7R3xx4F4SBTzOXUhkp5grTNQFoplFfSLiILn88Q8LLZehUqsCajnyaQG7arSJNwb0/k4cOFZdqVFaRgsBLMPvObsfz/SMbeMmc/ltIG0vByqQ6VqtJwf+mxK/wClpxDmeHZ8MYq0qqkWDqVP6ThgVyFgDb3xPl8wY/uL46qOIzw5eojEVco9NepowwHv3OBxy+Sdg5qvBbSA3LftBFsawtW9xiGvlqVUaWRWU7gqDhiozJOFeW5DCVM6ZAIg/wAW2Jj4bCiyEGQSQ0gj8p/LDzS8L5ZVKhSgPRSY77Exgbn/AA26gLl8xoP8VOQfaQcMVCs3DGV7MSsHapEdIaRIOJ1ylkQ1Fck3GqIPQbdu+PuJcNz9M6momsTYik6wR3hr/SMCMzmkmMzlalIC0mUgdTMwcFINhHMZajqK1WKQbET+UjfH2J+FZrKlAKLVltNwHX6SbY9wxB3hPhujlaemipDdW1SWI74vUy+qJ+hH9ZwVyuS0nmJIOx6j2b++LlXLD1Nf+WHaL2yvlaIW8XG2LD1D2kYqZikZ3gf50H88R0DonUzXNpuse3bEjJkpMTdoI7dPocR1lBmb+4PTFqlUVtjv1G0jscRtShtQntB/t1+cICDL5wAWIadpOwxLUc6dg3tNsR1+HozFtChyDf8A+sSUcuF+Pz6YAR9zmIkEdgIPtj6rmNI1GZA+D+R3xZoqGE6hHSP54VPFmeDOuWVjdgrG43mQPcUxUYHaQuEgCPDqwINZiBqBaegp7z/6o1fGgH0454Cnn1P3l7NUX7ND9yiDyjtqazH5jpgB4q4iFy4SY85tMDcoo1sB7mFQdObtgZxfxdWpeXXFOjUVBpbTUh6dVpgMJJ0x90ggwbgxGmkZu30a3QMWi2xGJfL08wO179sBvDXGlzVJKgBVmQMVPS5G/W4/lhI/al43NKvSy9NzpXmrBDvI5Qe4AOrTInrFjiJKnsI70N/iTiq/YkKrUKtRU80mUpVNcAuNiJGkDbXpB3xln7QihX7aitLNvVDIoOqv5AUqWzLhipZyAVVfSBAtOCf7HOILUTMcIzMOjg1aU3V6b2cD2k6o3kvsQYUPE/hxsjm2oXcRqVtO6EkD5IiCbX6RGOTk3KmdKiuyTwf4dTM1tFVuUAHy0MVKp30qdkUXLuTyjbeRJ4ooUBmGFACIGrQIo6o2pCJKRHMfUdRsCBi4tZPJBYBrEDSL3HMrN8G4sSpseUjFjKeH6lVEKU0LswTTqvJ1/e29Ki5G8mJxq8f2HewFlKJrMKBfR5tQF6pQ1HgAgBgDLJJNu8GbDAnOcEqZRTmSzUCGiijIwdzqhjpYDTR0zdgdU6YPNGl+G85V4cWqVg1OhUhTRKk1C0geYLwtIDUNUkvFh1C74orrnKtVm8lE812NZwdRoKugLIkmyhlUDftfEbsXsFcL4sMwpEaai3A3leoHWAdpvEbwST/B8h+8sKULsSSxKhdKliSReI6XvjN6DGhWBDbEEMNipuD8EHbthsznENEVFJGoSsbmd1tveAQPjEZYXU0dPj5NOEhj4pxA1q5qUgfIoEikPctqvO8aifqO2GXhvFs04UmgdEQYMn5+CMKfBc5kFBVqtRatM82pNS6pvY2InsRjzO+IQas0KppgWaBIt+HTcW6Tjpxw4xo5Ms+crHqtx9EOlmUexMHt1tiz+9LVW1Qi1mE/2IOEE5s1GIqVqkRJ5JBbodg0dxiWjxOpTgUXDDqUDWluogacXZkP1RzohCzHqRB+TiLhmSZDarUIInTv198Cs3m9NMRXl9yAtx+X9cC+E8aJdlFZiwsJGtfkDcDvihDtn82yELBk9xbbuNvyxPlMzqEi57AjCFxXxA0qtKqNViywTIn7tjGBtPjLU6jVPMKBgQCSDexJgG2+5wtAan5qsYBBI6GxxzVpps1OR7iR+tsI2U8UZt6BKU6dQpu2uGgjlJEAfrgnwbxLUrITp8llj1XVvfpE+0jDCwvW8LZJzqOXpiewj+WPsEFTWoLaZ6kf7Y+whl7mixAM9p/O+/vgFxTjtVKxpUcpUqkLcswSnJNoJknqZAxD4R8Upmqar94rYkRJ6gjuP1wx1JFjtHS8H+c+4wi6ooZPN1mVNWXIYk6grAhdrgmJBnb5xeVBEspA9xEfI6Y7ML0n364rCjzMxJGu7KROwj6fO2ARJ5a7gWP+fXEb1lHLuB0iSPrvGPdarIUAHcgix7x746WstzAn3F/9x8YBFVgQSxBgGRFxHcY6XNRBJABNj0n3/D/LFlMwd9uw7/XH1apYmACN4/z9cAHqmQBN/b/L4y+tnfMzbPNudh8SqIfyD4fMzWKUajoY0q0jcbW+LxfGX0G05hx2pUx+b1Sf54cQZc4/WLVqVOF06BJZgNOp2ckTtaksm0DqMCePcSyZDLneHnL5o02enUy1VSjkhtJOltMMyxMMd9sWM/L5h4pNWHkEGmpYFx5R5RpBgmTffsN8IPGqQSsVXLVcqIE0qpJcEjeWRTB3Ej6nGOWWy4xN18M8Wy+R4bTr1SxpmjSZq3KwZnGlqNNVIcMpAFxbc7GMHYGpUIQMSzHSJ1Nc2E9TG5+Tj7LZhqTCoopt/DUprUQ7SCrqRNokX7HGg+F/GXCXIXPcOoUG2NSlRU07iDKhdag7fexjKcmaKKQN8HamnLZcp+9UtWYo1+9RNAeivV0ZA2xE89mBBw+eJ0Ti3DaWfoiKlI/aLuQthVW3qgQ4PUAR6sM+T8McNr6MzllpEqQadWiQNJXYApFumk2ixHTArhHhevw7NvWo1VfKVS3m0GF1DMWBQj1aWYwpA5SRJMYy5RTcmUneinwfKouXRGVKoViyOh1wNUiCQpNiTud29wGPwzSSoql0aiyxoTWIqIp5KgAJOkhtzBkkdsJ/irhFLJU1d6rnKmoW8pWYA1ZZqS8g+zpBC7NF2IHVsAfD3E637x+9OHq1lZKVNKOkKKek8oEqoUMyKBI3O5x1xzRmriZuDXZrXjDw4ucpabeaAdDkC3cExYH8+2MOzCNRqMlRdLIbqwm47g2I+bEe2NVyX7S6NYU0p8lVtROuCoUU9aknUBzSvXvO2BnijhmvI/8AiVM0q1b7NqlTQLIjTyiYDAhQ3dQR8prQ0/RkXimlrC1vNNVgdLt5XlqAwlEXYNpgjlAER0E4m8O1QaY1CWpNKz0kGPyMnBTxB4iqZylUSvmSWCMyUBRVUUqQdesMDMahBBG+AHhx+Zx3X+o/pOCDJYWr1nBCoSATcAAg+7T1wY4LnKyOAChvB0pzwbbCRI+e+F+rxJFqaXplSLyG0OLgAhXsx69JwRyNenWJNKtNUH0NKk9z7/IJxdk0GanHNLMUqJrEKUcTJ7rYwd7YH5jjpqVDqpww+8GZW0gSRYQZN+uJslkdQ0gKjsbggmelm9/ixwSpZJlbyjS1lgYB1Mu31g+4icPZJQqGqClak3nlQC6luZbbTA1fG+OanieoSpABcTB8sLpEfjEyfyxVzeT0tp8tln1eW99PUwV1WO+DnBMhl6VPmopVWS3Mrao2BUdv4rYdiBBoKQGAKVWGu5Dr8wu036YhzlM01RmNLMUzyuQCdMe267jF3L8JylcVdGunUUsVOpj1tErcRcRJwUXhnmUFpqlPNVFAE6iCLCSBpVyY2gnbbAAt0c0Mu5NLXTWZISeZdxJZRA3tffBfgnic86EqQJZSwiBvHLdrTjvhWQrkBZFSmkes6wD/ABKwgWtGoHEfizKV2UD93ZFJ9dNj5eozupIKn++HsQdo+LjElvKH3dKFlYDc9SOlsfYSjwCst183VbVLiPbciD9Tj7DtgHsxSfJZlqK0glRDqpugYGtR+7MEqWBMbTMXvh78MeLKVdQpYa4ve+/06XOLnjLwwM7Q0hylVDqpVB6lYdNxIMCR8dsYfwcV8lmahVGJUxURoDLtqa0GIuGUfO8YxT4a9HQvn+T9FVKYI3/LELCQbSR0J/rgH4b8SDMJaBUSNSxEr3AMEbT8gjpgzURHMnSex6i9v1GNEZMgrM4uo1obR1Bi4Pf+f8j5ScTqm0bE/T/D9DiwXM7Ce+0+xHf3xHUonUSARO46T/QnuN+uGI4RVBmbSI+do399jjqqQDBPx1n49vbEakIDvBN5+6e8Hb3j5vviGpf1sNPq1D2ud5sR/nXAAG8T5wqhp7ByD7QDJ994xnRrf8S5/FTX9Hb/AOQwb4zxfzqrMJ0Cyz+EYVeJVQtemZ3lY9muD8SsfXFdIEEaqK1cai6hqJGtASyyKikjmAmwiepG2FniXAq1TVXo0s69BUDNVzNPSQBudUlSoEdSd8MdLPFCHULIIALRbnRwZPp/5emeznFbx54lzUNSfiRqFzBy9OmaYWiyyutwq6yVKgpcXNyMc2Xs1jZLwTwymWLPxT93o5epTIFOo+rM3AIekqAlWmLnoYi+FnhGQp1KmhD5jNUiiTp0lUeX8+ndwpp83KTEEXvAEt/nxtghxLUEpyOTSunX5ZqbE9Oc0421WFvbGaLou0E8sq4ZeRxTJpuB5ul2JOoQwUqVAaLgT0w38LyWaytIZvO5nMLTQSuWFZmbMkBmbVLRSRZVWMGIOxiYPBXB8hRLPxXTTddLJSqNAZGuGKLzNsRp27i4wG43xo57NtXg1QCQtM0mcUaAbkIVWANokHqT7Rm2pviv3/hpXHZL4h8bZnPU1pVQEpIwcqkWtpUDaAAxgGfm2A+XSp5ZqI0hTDANzKBBBI7TP+knoSJMtSyr12pioQhBFNn5QXB5dZiVVriwESsmxwR4lTFApWErV0qr0WQBWpgIxVoJAABWPbyxEgM1xgoqkJyfsGg1UpglStOrsxWzFTcBiO+4Hth+8N+IDVyScNm5qElyo8sKCHVSQCZLX2Jt03wn8czj1aFFlYtlUgKo9VN9IXS/cgCFP4Ym7SWN89lMrRajlDXzNPMU1fTUqoVB8xQ32SUwy11NOBJtuJxSlTIlsgr0PJFWlTzVY0mDEU0pk0qh8r7zB5V1I6K0wt72VeCiHH/af/Y2Ni8T8DQcPdso9QU8wusZdQKlNqjRBVtJvcLFwSEsN8ZbkMrDR7R+ZA/kTjSC7M5M0/O8N84EV6SVF7GxX3U9D7iDhW4v+zYOwq5WtpKwQlUalMGbMASfqD840NMxTeGVgAdht9Pa3afjHCsFaQGnrEj8z1+sY1aRCbMzzudzmQg1qTCkTdQoq0be8jSTGwgi+DFLjeXq050Nl30g3EpuY0wSQJjpGNBhamxMxcTuD3BG3vhf4l4JydQ60+xeb6Byk/xIbRPYicITKHEuCCsi5jzaesTD+qk0WIJDHTcRIxDX8wLSFc+WskB00FNtg8EMYHWThd4t4N4jlK3nZaXXVM0LSOzpufiGH8sXsj4sqctLM0qTsxMimuhwQL2YMj/B0EYVhQXy/CGJal5iNScCBVb1dTcLBuNpTHVfgUSgmmeunS2mBuFaGvHRmPzjnhXE8mUAXy1JgoKo8t2E9T6DE7g7RcDFCrlc1qLqawU7EqWH/wCxJIgWK9ve9VYrJsrQzS6qdKvSCpHMtM+eoFyLjWDe4IIIxdfya2hnqlWSGZkJCubFpP8A0iNyIBsMSZQ+aFSvQUNceaKmliZPWS4sIgkz2jFTO5XMkOq1qMREVQgcCPT5qiI6QyjoZwvkh/F9Eh4tl3LIc1lmCkafMXWIjo4CLbtBO8nH2A2V4IHQDSFqgnUoZKnLJjmDAnbud7wcfYq2S0bRTrdYmdpP5QfeMJv7SvCwzSjMU6fmVqNzTkjzacglZH3omCJ7YcqmhhpLXEHe4MW9xjl1IGrcgQ0Dfv8Arf8APviWrNFJp2j85cN43Uo1UdNaAGVJBEJMgEmx3iTPWZBON04Vxda9MOoBYgEhQTc7m1yJsRtI36lF/ah4WhXzVNeQA+Yij45o6SNyOoBIgkhS8IeLWpOh3QEnb2AZSOvaD3BneYi3F0zWaUlyRt6Vkra6ckOpAa0b3BH4lO0i/wAEY8Gd08jz2B6yNx7yP86D7g3EaeYpB1kWBKn1CRItvdTY9Ri22gkNF9gffYj2NvrbfbGtmBBXqJEg3FiN9+ltsZ9478TrqbK0bf8AmnpP4R/X8u+NHrZBSSwUS3qH4uk+zfof1GIfthprSzoFJyHqoGcFYIMld9r6b9jPfCcqVjStgbPcfFPkQgv3/D/ScLOYzZasanUxeSbiL3J6gGJgbC2CWV4MpWdXN84FZ7LFGvjn+pyZ0PE4obcvmQ6gmwYQfb3+hAP0wVqF62WZBUoZZQCuZrVE1OaIIAUPpLOQSAES51JfeEvhOcjlOx/n/v8A3ww5DNQ0wGtpZTEOpGm8jaLGItHQNjR/JGS0LWfyiBBVoktTB0OTYhxMGNwHA1DtcdJOlZTw5k8jk2fNUPOEUWr1WpkgrXDAJlW1AaqfKzMJJvtYCZjQy7Nn8yozFYMKGSyS0yq0iByqU07gsYtcHVGpoXPfEFDNBSKjs1Om5BpBjoy9SYamEJIQAyoIsRF74xL7KByNWo1IMSzVFQKWJOnUSlNSbxOmw7EYvZmvR8mmwRKbog0KNRapqZ9VTzFI0sjrZGEQdz1GZBatSolKmza6joqjVHNOmnfpBNj0w88T4BkaHC9VQOMzrqIasGRmqY5qOn0tR3XzFJ5hPsAbZn84dfDLnNfZ6k/eabKaRY/aV9TQUkgguoUFWPphRbfCtwXICvXp0TUSkKjBfMf0rPU/yG14uN8aF4z4dleHJSNDzaWd1b6gpNMSpdlUkUgSJSDqIkn2m6K1dHB8LVjnNLK9BKreYumj5quFZVOqmhVtAfTOoCJBIm+Fd+FVP3o5emo8wVHpHy2nU6s6kjU0cwBAWRMREm7VR8a5ioMvRPlBH+xSqtOK1JX0JWZAj7sTOqJmYvi7neGZE0mzFNAcvULI1HURXy+aSLUyeZtR+6bkHpygJbG3Q+Z7xhQy2Vy9KjlyzBKZCNKrTgSQW0jnHYCb3jGU5zMu1bzEpg1KlXUEUWu5gDsNRbfoBhj4hx9q+WVKy6HDGoxmVHIqm28jSTEneB0xQ8NAEPVdCfM5VAJDBAIABkTPWWWYBkyRjqSOdsYiEQc2oERrKqRB/iU7+0jrbBHh+fekJI81Nyy7jpzKTaPzOAx5RSh2AHoPYe4INjtax3M4mpkSNJEgTqQg3BgxAGq5uR2xZAxUc4j3RmG3S4tvcSvywx21U6dbXH4gDtbeJH5E+5F8LBzjFzSqoCLlaoYNcAG4sVOxm/1xfpZnTGmodXVWmZvcyQykz96QegO+AQey2cEAi0izBpERM9bfB+T0xFnuD0K969JWYempphx8OpFvafzxSovY6tIjdka4sCNQge8EheljgjRzJA5pIAvU1W+pgENEEmEHYnAAl8Z8B5pGNTK1w1v+XVUaTaPUgEmPxL/6jOA9DxJX4eStelXpahyqdD0t5+zPob/fGs1M2EWTsdrSG67qD+o+vXFStUo1F01KQYOOYMvmKfkEXte9hgCxH4b4gynEaZBVadVSJMR8MELEMJmwYHBvL8HVgqDyM0FEXA80RuACwJA2s5267Y6r+B8mVf8Ad/8Ah9fqC89Jxf1KTYb7FfrhO494ZzWRUVMtTFVgZaoqmoXVjdWTSTYgMD90DfBbCkxn4hwYEhadUUSPu1KXmEDb7zAg27Rj3ADhP7QalZ2ptSOlVBEqHANgRzk6YJgQbwZAsB5gsTiaFwqiCoeo0tZfTpIYcpBibzNie+DP7yOhnb6iw/rhcztUo7OqlxdtKg6WcA3Fzcrp3HqAIsWItcFzztQBUAuIC+kB+o+6IVx1i0264bGg5A9IEq21rRFwZ3+N/axxgfj7wRVyVcVaC6qNUsyaP+mZ1R222tt8Y3PJVQBp5tIHK5jaTAM3lYEkj5vqGIuJU1rr5NVFam6xJsQxJ02Pp2BB3DR7xnJWXGVGQ+BvFbo6pHKZUmYP3RF9vTsP4YjrrlE03TSpZE6wYiCLEj7pteNmBtBxgHiThNTh+aajU1Gmb03jTJ6EbiR1GG/wj4wqeWACpZG0upN3S8j2IBYqdrQepLi9DkjUa3FKSLqL9QsTckmOu4Ivq2Ik/KF4hzmXzs5fMZVtKH7GrRZWqIDN+nLIvupEbRqHPiHiKIabgF6NRRpYhNCqbwWiSwKtAuDMzy4X0r0kNJVDs9KSWi4LEMOZWAvrAhbf1uk0ZW0xMzWUq0CJkoSQrxEkbr1hh1En2JF8fVmFVb798aPna2tKtNglWnplqbgqoN7lyZBDTJUz6ZvJxmOdomk0rzU5IB3gzEFoAO0g9Rjmy4uO0dmLPyXGQNqIUaDgpks7MXhhscRVlFRbb4GGVPbChMWTHQ+8D4y1NwyWeeaWAEQFm8ekCzFh5YnazL1R4FQrrQo0uSkrVKmaqEhswYGvQtvtAFVVXTql2LREYT8tndpMEbEWv/Q4M5fiAOkMSsNOpIBO0g2NrDoV6lCcW0n0Zp0e+F/CtSvmMiCxRMzUcqVP2qpRPO20KZVgpvdTa14vG/EcxWzL+bWq1qdOpUp0XcASqNBjSApJsSQJ2nphl4d4hzNFv3pfKrtTBRS0moKZ/j0wolmJBYbmFGOMlxWjRfLf8PmF/dHqMqg6r1GJJYhSdgsQfwi9ziHFlXuxAyyOWXywxeZXSCTIvYDeN8bfxDwqudo5XPoDUqV8vNVqlRjTFRUFpBJS+sDSCJAsLymcIz9KkMoKdHMscrUeomoAAmp5WpWlYIGk7ETzX2JIZHiWaTLU6FMJlaKToLtrbUxDkA7E6gWFx0MAjC4Nj5AujwShSTVVcNSq0RpqLHmpXWtp+yA3RoB1GxWopmRgvSq1atT94q8k+lLapsTUciPtCFBPwTO8Uy1KgxeszPU7uZY9OVdwOxiD+Lrhd4/4kapKjlQ/dG5+ewsLfEliAcaxio9kSk5BLiXEBWqCjTuk8xBjXF4B6L79Te8LhiCU6YRWGmYOliVO33Dt2Nj9BOA3hHhq6RVYgGJJawVQQNRN4QEgM19BKlgVYFWDO5paraSoKrKhXFz+KxmCD7n5NjjREMiavDCC7AzpiZDWnY3udiy/OLS5mZKKJtMKSGiILI1+91BA/EYwMSjTP/LUruWVrgXkwZYgm22rsItizQI8sBNMG+xE/wDadpttaJ3JJgJDOSrMwjWpNiRqJMT+IsGPaQ0exx9xKsXPlhqlOohBXSAwgxYa4O28aR0Go4F+QD9nLLVmSCpOqbXCgTuRNxffFziFaqE/5aagItIRluLzLX2sBeTMYYiXzXJDgz1GllsLlT0i9tgTaSRGOOB8TZCS9Qa2EHdSVkjmWTJ3uADadUY64ZmPPUuUemQI9S61NtLKTBYEzfe25IjHVThxU+ZyMR2EPIMywKhRtMEA23OCxBmjQSoF01DTOr1LBUt2IurdzOqO4x2KtSnPmhY2L0zyk2N6bTpmCdyb7XvRqsoQQkM/aSDLWA/CepQlQOxx9w3MMSyO8lfUCOcbRJ3A6zCrBETuQQUTNhiYgkb6TpZRcbGJ2MC5xaoZrqN5iI0kH3kw7fG2A2cahYNFJgSQS+nc6SwfpOwupbtGOnp1VjZhHoYBXI30ysIY39Cju95CGi5ncvkcyf8AiaKFh1YFWnqNS3aOt4nH2IcvxinE1GqUZ21CD8TJU+xViMfYBgvi2Qriqr06xQNym2m0GCSo1Biwg2nVI2fH1DjDNkajKURtQZm9QWqNJJKxJSpuV3nzQJlQb0nkLMon1ibF2UA3B2MC8RIQ9ZxcRabhqdZQZGkiIDRJbaN1lxpiGFSMUxIpUfEqE+YDoA6MfVbmvtBI5XmxEyNb4tHiqrS8xzrOncGTUQ9F2UtEjpck7MDgIOH0qNaop0EJB2B0qV1FoNuUHWVtK+YBIQak7M8XIZoN2t1iBAAvfTpGx9tjcFIdjdxxcvxGjUp+axtKswgh7FWN7BhqUnlut7QBkdZK2TzJVpWpTa/YjcGP8/u48DzTrUBp09bN91trkiPfa47D2kFvEnghq2VAUL51InQomQI1NTINyROr3Em9pmUfaHGXpg/huapZhadPVqBLaUbZW0OxUWtMkgHeDcxgmMlS0KKTRURgLLAKgMpsu7aRJAvIOm+Mw4Tm2o1LSrqdu5B97agbjvt2xoPDOI+ZQaoagUzpIkAGylTI9J1NI6CYNpGFGQ5RBHi/iKaiF1q5XSxRj5Zg3htI1TeSBc9Y2VM1QCgt3NmmdSlQQCJtG5uYPxhi8U03eqCNR5dUFYCzPWSDtvt77gLzGeUiDMwvTuCPp9PrgkOPRVoFlvDaRuegPzti7Xy61BIx7WrkATEFdhebRBMQRb9O4kUqGa8trEx27Y55w9o6ceT1IrV6BQwce0swy+/tglxLNLUUIgltyf8ANsQ0KSpfc9/7f3xULaIyUnSOqeaKmYZT3H9xfFylxpxu4PQ61ViR7lhP64reasFtwO2I8xmFjkE+8f06HGnRmFl8QPY6kkCAdIsL2HYXNvfHC8YqGQjEWuKYCW99IE4A1c0WWDghwviq0RakGJEEsYH6YVjor1s6egxTLSZODWR4eXJYgGTcfr9MGcl4aUm5YHoP126xvb8uuCmxWkBqHGKunRSJAF5940yPfTKydwBa2DPh/i9UDQlLWBcg2mLmNQPSNxb6Tgll+DimYYR/ENhfcjcfIt3PU2+G5QKSxEamiR6ewuIE/EdAYGKSZLZfyb+YJakVMelrQxvIJswPeWHuLg/NxGpTlGpArvpMXE3iQQY36kT+fVFyjAMjAarsBuYjmiFawiTG0ScWcs9KoAtQUqqhiAVvpAFjpnUhjtbtAvi0QyllsuZIWsVWdSLN0vsYY6bmNQvt3uxqusEMQ9oNgKgMb9nHbUs2jVMYWVWizaaZJKGdIJLKQIOkkRUAtCkBrnBrh2WBA0VFYAcsz+GI3AU3iNyRJPTCA4XLUiCFOqJsYDC3Z2gk+xm8zeMfZSqWgGHUC8rq8tjYQvrUSCOWYv6sWK9Im1TQIA5YPMIG3X8yRcwd8QppCgqFA3GpgG1ezkyYNomRJJNrAgtlgOZkKMsmQSN+2q222k6W29oqrluaVaNRupjULaZUk2MADYbWNrR5JEaHp1ST6YiesKp1MSoBB6kdTsDgdxTjGYV5A8xJMcp06QQ0kkxHuIEdQMAg/wCaHmNQa8mxIiLmDqKnaGnbob4EolUGKVVLC6FeWLDmokwon8C9dx1rJxalUPNKNA0MGnqdoIkAbAwJO5O06ZLSoBdXG8EHT3AA3Swtpn1RFpwDCNLNTBqVRTYgntTbYCC2q47dOlseYjoUag5gzMpsCOY2j76gGLnlaP7fYAO+AsjoqLUVg1IKdTBzMQJBjVuymNwVH3TigmapofLNVVVGDI2qSNMCJIJLBobm3ub6jAji2SqLVFWnKMo0uQ1gVPMfqulgBupAjcYt53gZrFTTUanYh+bkDXb63BFhEC074sQQz2bOYzBanphQCtRSOVSJ01BF1DdiYBbedOB54FTqKukClU8whwsnQosyaZPMNIIA3Ukc0MSvcP4pWoMwBKsCyurKG2BV1bvBBgTHbDVwTiqNpOnyg8IbalBAPlvM3IjT0LLAO1yhg/hPDMxQzTBitOZTWwmmSy8kWYGYG1736y4ZrNIKYr1W0xTGpgdRAjdTJDOrDl3LCAZ1A494fXNXXTJhVGhtUXQgFZB+4wLrJFvgkYTvHHDzSqJCnyQoUNzHSRsbm9mC2nYDoCEAA8a8Kp5ktm8sAGW9SncErJIYC9iJmDa3cYWuD5zUDTJ5WP1k27iJmD7n3OD2dzALNUEhiOp1TIAb1CRN7dIsbTgNx3hrL/xNNCEYy0HUASJ3ge+/SD1xnJVsuLvTGbhtWk6eVWY3XleZKzEATBvuRMGPjEub4Tl6BkAE3ghoBYGGUyY3PWOnQEhZ4LngSBa/QgG8GRcRN5U9x3mW3LeIUeiiGmHYHSrQJQ7G0CJhyPiJtJaa9g19hDzcsbiFAtBnSurrHWSPmR7HA+qlpnb88P1XNl64TyjqpmzMkqARpkwpBUgnlaANRuIAx2/AK1Zmo1KdOhoHKqLAcE2PqGqIEGDJ7wwA4jTM6WsQIjHBqE4Ncc4YtGo9OSXViGkACd7AbWj56YHpSi4P+bbe+M6Zdo6oLqv1j8/748qUSDKj8sEq/C1VEcOB5i6ghn/3QB2/laL1MrRvIaAN4/lH+fXFUTZZ4XwzXup+R0tvH+b4JUODGYJABtcTJ9j/AEO3c4O8BpDQWpszsovTKw6tHxt8iPbBTiHCSVDCkGRxz6TFjsdPSb3mxBv3tQJcgRk+E6dl0xEG3yCIJJ+Intq3wVydUgcylrwCvfpMELfoQRO8icCv/Ccwjq9NmqUydmIIAJuGA+oldyO5jDIvh9joq0WLbcs6ZU26ncSb7z/24EhNk9DLs0sk6iBaQCes3I1GPboNgJMeVy7cyGn6bWWIJJPyu4juCYB9QKZZWUSw105AkrLrsbx/zAIBBEGwtgg+ZICtdxstTZ1WSYJPrU7QZ26nZisRc8+apzCOYB1GLkEEk3Y6lt01L8TGBT16NXSzEU6h+8BC6hzDVpWxMGSvXTIjd641mZ0tSQ1P+19IAi7ARIYCJB+h78Z7hDWZoZWgqdIabWEqPTc9BMmScFBYM4VVok6wZciGDEK8T+MnnMTebzJjpYajT1MxfSe4krNxePSInddoiJMVsvw+ieRaIXUQReVPWALbQDpvA1TFsW87lrEQJC2aRqQAd2nktdXMWu0xgEXBntSxVhwLQTBFr6TIAYC0Aqd7mcUqlYKCQVal94OVEE2ghgDfsYsBuROKlbhua0SHpkrsygkMsSA4+6LWNx2J6Dc7m1c+UAKbTcsW0R31XImRY279sMQb4bwpajO9J2pE70wTpIiIN+WY0iCBHeRiKuwpVPLQnUdhqUuZMTBMVJ32VrqJJkYB8MevSqaUBZFmUM60UnmKEMuoW+7eIMXw0F6la9J1dLWYCJuDK7FhaBBYWnocKgsHZfKFxqWmQhPNaW1CLx0HW4N9pweQPSEgDSR6lBMixNt991YETJLDAvMcVZG0NroVLDVuhB2gmRe5hiQI3GC+TeqFJ5ai3OlTcTbpcGx2gXO2+AZzSqguzIoqBoJAM/DaSJA3ANxGxHX7FLiHB1Yk1ab6TfkUgz/EFBk7mSq7je5x9goVlnjGWfmcxpJGogSSpsjRB5leQxF4qD4wv8GzFegK0U5pzrUEwadQMIsAbAhQYF+8A4aRxRVNVKs+UqMCISIcydrxpse5B6xgDlSi5hgW1U2EORzaieWmzHpqlgx2k1Z6HFiFvjYaqWzASFZhJ6qxAAkDpbTO23vi9w2g1Sk6VAFKFVaZ1L2Jn4YH2ubKMEOH0KrZipQbV5FVTAYSXQmFIjZxE9IZZIGCnDa37s5pZoAfZ8xEw9NeXULbGNBE9KZjmOEMEcNyGZy+Y9RIUlSQCTBI1A8swYB/0E2N2GtxdqTMldPMUJJKICG0+okaoIYax0AOoGYkD8xxAIaT6qlNCdIfVYCNzYgsBqB7iD6gcGMjmlragFQaTzCVIaDDRcgmVVgf4lM8xwUIGZ3hGQYGrSUH7PWKesgOCGYSJmbEexAsYMCOAZmnVWrlyCtJkCrSdZYkFvvTY3beNgBGwO8eyFIhsxREMRDFQQF2KtpEESdLSBYgGxmRlcmtqWuoFQKG1oJdSpKa2AAOkmFIAn0mIliUBmXiLglTJVtJhqbehuhU7f7H/wCsecPrmVZWUEEEMRsRcava0e36405/DfnZV6NbzCSuqnoXW1NpGpTInSC0gT6Se18lrUGy9RkcbEi9p/tG3cYxlGmbxlaNO4TxFSnmhklQNav6qNQatTQPcsRMAgn3OC2WyalF1uruCQSLGBZmVQ3KCHBKiYLWG2Mz4XmHDSG9QK/hDpvDGCJBggkWP0GNF8P51tJb0w2mpcspBvqFyRNmgW6g6cXGRLQCz/h+gYy4pVBopsQ9tOkTEsCL3BkgiZ3FsK1Dgphy6MAJirrASemqbET1kY0XN1AzkrBS+o7lWG5uCYO0MIIPuCa1VBU1o0B6ggFVMVAIEAgzPUyLe4wVsV6M38hp0FZZSREk9doG42NtxgkMiaCipVRSKgIAnmiY1E6SLkWMjfe4l4ynC6QAhdOlNGrZiTDEMARFrzfod5kfmPDzVGSma5KAkoHXZiWYquwNx6e82BkBqInI48DZukasqkswIK/HMpA6/eETPtAnGhDLqUkAmm+/Uzv8xbaJkfTCV4d8NUlqDzmHmGeUvEgEQwHqRgSD/YxMGT4i+TzVanVqVUkjma6EAmeUcs9Awi5uRBxS0T2HuHZBMu7Q76G21E1NMidJvzC5MiZF7gE4kWuZdVBVt4F1bpyjeZ6G9j6gPLwRpZlKiRTOokEkxpBuCAQTF5222MiQcUG4eOYu5VTAupJVluvWSsD0wTBmWHNgAI8MzWux5WE7XEzMG3OCSbjmBmYMxbqUgwYxoa91MjbcbfX9dQiRVPLalVgyEz61NnvNj1JHWZiNxIwayeb2VgA4AMWJ6CbWZb+qx7hcFAVjw2k5UsqtYXtAYbEEAEERBH6dcVeI5wUqVRkpSRGpAJlZgtABi3WADF98GKgQbAKTdgCYtF97QYv0m5xTzVDSpVnJBMhhJ0nvywQN/TB33vgAUOCeJGrakFLXAEoV1ApczYTAtzDYsIHTFepx6r5hGhmpEkI6OWaJvD7kQG3kjabHF/i+Uq5V2rFhUpsIIEhSQAASR6O+oQB1HXFvI0KcqyE0z6lQLIIvJGmzDryjvbCFZXyZJOoVgqzAJhLmYWIIHX0wGm6mYxV4rwQ+YG004NtSqRpI/wDMQN6dp07T6VjBOrShR5uoyBpq0wC1uhWwqJ1jfttOPKSKIJ0Bo0rWMtSqUwdUEzqRhBt0gmMFATUtFPR5h8moqhZkNSe26sZFyOsG1hifMZUaTrDFmgjSQCSL+obwRtBW+OqardV0Cp95KgBFQeoQ3pMyTKwSYJFoMfmqg0LKf/iYkoDeRTYCQP4WHT04YgaazPTcMTmKSgAkL9rTts6KIYdZBB7KTGI8tk0ISqr+aqqAOaUsQwmBCERJ1LG0k4JvRVKgvoYyVcCxkg6WA9QNtp6k7Yo12Kampk0XInlIKnm3GkaWmZ6GwkNhDDCZxSFVuWRqCtysPpq0sOb1ISv6Y8wuUuIEqNYdG6vQKaGPWUqNCtfeATe2PsMR/9k=" alt="watch">
                        <div class="caption">
                            <h3>Titan model #201</h3>
                            <p>Price: Rs.3,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(6))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=6">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://i.ebayimg.com/images/g/kmsAAOSwulBZkuYi/s-l300.jpg" alt="watch">
                        <div class="caption">
                            <h3>HMT Milan</h3>
                            <p>Price: Rs.8,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(7))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=7">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>    
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQTEhUTExMWFRUXGBoXGBcXGBggGBoYFxUYFxsXFxoYHSggGBomGxcYITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFRAPFS0dFRkrKystKy0rLS0rLSs3LS0rKysrLSstKysrKystLS0rNzMrKysrLS0rKystLTctKysrLP/AABEIAMgA/AMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUCAwYBB//EAEEQAAIBAgQDBQQIBQIGAwEAAAECEQADBBIhMQVBURMiYXGBBjKRoRQjQlJiscHwBzOC0eFykhVjo8LS8UNToiT/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAHBEBAQEBAQADAQAAAAAAAAAAAAERAiExQVES/9oADAMBAAIRAxEAPwD4bSlKBSlKBSlKBSlKBSlKBSlKBSlKBSvYpFB5SvYrygUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpXooPKVLwuBZ9hp1qdb4cB+I+G3xoKlbZOwraMMeelWdq0C2WY8vy1qZawSztJHWgolw48T5VIt4MnZDXQ2bQG8CsxirS+86z4H+1BQjAN9wDzNZrw9zsq/Grn6ZbYQMzeIUxWS4lRPdc/wBNBS/8NufdHxrXc4e/3PgauRxe10b/AG0PE7RHvEHxBoOefBEbqR6VpOF6GulOIQjuspPnUbHDaPM6aR58qDn3wzDlWoiuks4QMoJ0J6Vhc4YemYfOg52lXV7gbRKa+HMVU3bRUwRFBrpSlApSlApSlApSlApSlApSlApSs7aEmBuaDxEJMAVd8L4WCZIzHpy9TXuCwgVSTrG5G5P3Vq+wjiFyDunTyPjQYnCwve2GsAafDnXl+2FAYkBec9PCscTxVLchO+Z5+6vl1qjxWJZzLGT+XkNhQSUyF/qwSSZBZoWfAc694gLiRLgTyXf+9VocbHzr1nmZP78aDxmB3JPnQMOlbsMRNSMW3hQRPpjLGUwBrHjS5j7jbn8q8gdJNbsPhgxYN3MqM+ukldhr1oNHa152lazWM0G9MpOo/vU3EXbQUG2HVvOAPE8jVUDWxblBYWuIMDrDgbToflVxgcQlw6NBiMraa+B2NczbUsYUEnoBJ+VShhiNHYL+Hdv9o29YoOrWzvIiD66c/CoHFOHhxqAehG/+aWDd7OINxDykZo6Axp5aio1632zhrbGBoQ0hkPMmTv5eVBzmMwRTUajr086h12uJwYcZlMn5Ny1rl8fhcpkDT8j0oIVKUoFKUoFKUoFKUoFKVkikmBQeAVccFwWbvddB5Dc/pVddSNP3NddwfDxaUx9kfE94/mPhQZXbIy5I7ux8PGqyxeTMEkpZnWNWbz8KlcVuQMoBBbVh4bfP9KrFWgsuMNhoHYjMeZ1EeEHnVMRW8rXhWqNNlsoIcPDa6ZR695T8qk3sRh2B7lxDygIY1/1CajLhJJ7yqAJ7x38AACSfT4VitnrQb7QtSPrWGu7WtvEw5qw49asqFNu+t0zBC9I94nl5VW27ckADfSrLieBhVbLECP2N6CoS8QZGhq64L9Z9KYgd3DufjPXyqkulRvV7wr2LxWItC9ayhHkLmZgWAJB2UiJB3ImgoHWANR/asUBnafnVo+GsW9HuNdddCtoZVBG4NxxJ/pX1rz/irKIsqlgf8sEufO40sfQig3Pwouqs0WWPJ9Cf9KKuY6eH5axrlu1bMFWuMObdxPQCWYeoqMjNmzAnNMzznqZ3qdZUXdHfvyYLExBjYAHM34dJ8dqCPcxjkQCEX7qDKPWNW9Sa0otSMTh8piAY0zD8j0YcxyrAJQSbGOdFKhmAPIGPnuKjreYNmBg/vQ9RWWSvRb6AnyoL3CYkOuYEKAO8Oh8+lRuLYIMJH2tD58j8ajYEm1cGZSFOhkGInfXoYNdBdH2Dq7SYUaKBrJPw+NQfOWSDB3GlYkVYcYtReuDxn4gH9ailZFFxopXrCK8ohSlKBSlKBVtgcJEdT+4rVwzCz3yNOXn1qwxWJ7ICIznUbHKOpB3PQfshB4jh4d/B3X/axFdPgb5+j22C5kyd+DBGQZd/NT4dSKobtzNcZWP8yLoP4nGb9T86uPZPF5S1ljEyV8/tLr5A+jVRm+Ae/iOzSMxMDNtCpJ2HgfjWzifs/dw5UXShDTGQsTpG8jxrLiNuLhh2X7QZCQdoMEGRz51FjWTcuPy+scmJ6SfCoNQwwp9FH7FbmuCsDf8A3pQYfQhROHrIOhjkdttJg6+VeHFVrbFnrQZ2uHZTJaR6TVjibwZMssDrOogg9YE7zPWqZsS3WtTOepqjoF4+MPZyWcNhwwGt0966ep7w33jkNNNKrL+JvE51v3nLiSR2yhxy6BdN9YEaGKrVWpVuxnPdjMo2DAMY6AnUxyEmBtQQLuVm/m/7s2UE6kKdTAmJgVmmGuDYLcH4TP8An5VNbD2iTu4K/wCllafUNEeRDfZO0vheCIdezuFCDynWDMGDr0oK+zdt7OrKeekx6b/KrC/w4IQHDITsHRlJ8g8E1I4raxCAh2t3QTzALCJ0kiefyrDBe0F633QHgjKLYZypaIHcYlDJ1jKegjkEm0/dKXAWWInSTuYJM8zvuI5xUP6GOQq1dlBQXsN2bFSxCq9th4uEyqvM62iPGtVxLZUm1cZmA9xzbMnoHm38rZoIH0Pwrbgrj2bi3ba5mUnQnQypUg/GantgLgggK06jKYb0S5luH0Wot9iphwytE5WBUweZDCeXyqDbxni17EhRdtIoUkyszqIjVjpV1w6wBbz5QCyqSebNlA1+QrmTdkwNzoNfQVcce4gLFjIsh3GVZ3gCMw6AfmaDhuLuGu3GG0mPId0H4CsrPDCbK3RzkEeR3FGwDm0zhe6CFnqSQMq9TqCekidxPa2eDlcJbB3C6+cCf/1NFlx8+uWeVRWWNK6HiGFymqrEW5HiKHyhUpSiFbcNZLsFHP8ALma1V0/szw/6trzbageQ3Px/KgzuhbVvMRoNFXqeQ/U1zq3C9yW1LHWrviLm5uIA0Vems+pOny6VUi3lYEbgzFTW/wCLmri7gGuYa0yibiJmgbm2WMaeGV/Ra1xmVbyaHnG4Yc/PSfSnszxfs71k3CQiDISNwudnDeas0+lfScH7IWkvvcPZjDXrZzqdES5mVhcVlI7O2Qraz3ToZAIqs2OYtXfpdsZNMQmy7doPwfi5xVXxLGKWnUNEOCIhhof3+x1/Gf4eXLbZrBMyCEYgMenZ3BC3T09xj93nUB7i3GAxataxCERiAkuCuwv2yPrAOsTvoaqOXYNlD5GCEwrEHKTvAJEExy8K8s22dgi6k7DrGv5Ca772k47i2w/ZNYsNZYQb6EvbaPtLt2LSAQDmKmuCuWgDoZiNQfXfTbrpQWlv2auRnZggEa7r3tszGFjT7JY1W4uyFJGYEgkHKZGmmjLofMGKzxeKe6zM7lixluUneSBAmdfOo5oMYrBqzJrE0GKidBE7akAepMADxOlWV3HBezRkF22gPce5baC2b3b9gBo1nLMTuDVeumv5gH4g6HyNWlrhpvgOhUKO67utmzbB3hQrd8wdYGaI0oMuNcQw7qos2WQqFXMYHdUNowDNnJJHeJkBYlhEa+AgXcRatG4lkO0dpc9xdCdfOIHiRWkYIAmWBAO4nXxEgGPMCtuHw4ZgqjfSedB1nthgsPh2tm5eN4tMWbJtg92O9cfM+VTpsCdeVc6faO4ulhbeHXYi2CXYdHusTcI8AwHhW/2g4YlsqURVUiCAoAkDw51QvaHKgl8WxovEE2rSgHNABk+DPOYj1B6knWtd7AQRIcAiQTbyDlompzDXfT51rwuFVgxd3tgR3haL2xMxnZWzJPKFadayukKe6LY5Tb7XK3Ofru8PUDyoM8MLiHu3iiyMzQ8KJ3YICSPSup4rwvBDDG8OILcdRCrZFoFmMwGtgA9dTsJrnuEYTEXSTZUwPecwLajqztooq2z2LLZlC4rEbdoQewQ790NrdYdT3f8AVQQsFh+wVcRiNJE2rf27h2zRyQfePPatGDwbYq4b9+Rb8NJC/YQn3VHNuU8yYq0Xhhusb+IuFp1LMdWy76/ZQbSPIeEHEu+MYW7YK4ecgygBrxX/AOO0NoHM+6oMnUgMFhwm2MZfRET6i2YAXRWg+6nMLmI7x1LMD1r6NxfhCi2FG8a+J3JjxNY+yXBbeCtBrsFzsijnqAFnZQCQCdTLMZLQNfHuO5iQz27Q+7nGY+ZbX4AUHznj2AgnSuOxNuDX13srTAkBH6kEP85MVy3HcFbae6PMAfpQfPMQnPrWmrLHYbLI5VW1Btw1gu6ovvMwUebGB8zX0T2ky4a3ZwiasyjN4W15+BZh8Aetcx7AW1OOtFvdXOxJ2GW2xn039KsBiDib97EuCMxhVP2UWMo9FGvlRrmbTEoCum4qouJJ1357fvlViz78p5edRnImCfWT+lZrtyrHt/aG/wCf+a+jfw79rAAMPdMqPcMxA0GUE7EaROmgUxCsnCvheYmf8/KvMOrA5kHenbr5fi/Okqdcvt74W/YQvgnt3MPqGwt4f/zsdyqTrhLkT3dE1JIUAFvLeLwmPP0e6jWMSBH0bEHLeG8HDXyPrFiSFbMCIjKNa5b2T9qs+1zs7oWM0Srwf5d1PtjXTmORFXnEMThcTbCYlEsme6WlsMW3m1dWGw7E6wSk7ksK042YoONcAxeBZ7ll2e2NXhYZR/z7RnTT3xmXTRqpGxOHu/zrPZsft2dAfEodPUV9Bt8TvYUKuI7TEWRqlzMDiLSx71q8oAvptOYRBILkaVyHtKllrxuWbtkW2AMiy4UzuWytlR+oCgaTGtVFS/BA38i/bufhPcf/AGnf5VL4Z7E371stns23DQLVxwGYdZWR5dahdhPumzcH4L2vwuIo+dZLdup/9yjwGdf+mWWgqMbh2tXHtMRmQ5WysGAI5Suh/Tao9dGnGA/dZrNzlDqs/DT8qsuHcHS+Y7C2J+7I/I0HFVssXijBhEjqAR6hgQR4GvqC/wAMEOw+DtW7DfwxyNnCW3j7NwllM9VYRQfM34kGBLqS5ac+Y7RsF0A1Op12AAGs2XDsZhluE9rAHullaTEdNBOpidPGvomJ/hp2oANqwkGfqrYQ9NSgBI12qFiv4ZLbEkJ6j/yNBzXGOPYZrQXtbbEyIykldtU00J/SudNjMWFtLlwZhkeMkqD0cblduhjfaugxfC3tEhVRY6Ko9dTFVeILzla6J3jtFAAHMwYA86C+x9nhqWGULeW86AFyyqymBIyW+6RI1AUg9edc1Yu2LcBLZvvyNzRZ8EXVvWKysYa2VLrN7KwUhDkSSdQLjiWIGpCqdI11FX+Gx1q2DbtYYEsCvda6H8GDWyrgRutwkbEEUFXxB7rADF30w6CCLTmCOkYe2C/qyjzr3DMqlRZwt6+xMK2I+qtkk6ZbSHO3La4J6VJwnDGtxkthSfs2Mj3ddfrLxJFpTprmf/TVrgMAmrYm8LVvZrdhibjg7rdxJGZgY1S0Ap8KDO9wu5i2FmFusqr2lu0SlkEaTfuAfVWVMqtpfrGgzkJM3Jx2A4cchdb+MjWFgKqiRatW1kWbeshdzuZqu4h7YZbZw+EtjDWghFpgB/NEFZQj3WUMMxJbUHkQfl17B3VL3YZjmIzfaDtJOfo0T5zIoPpvGMScanaHH4fB9mYey15jcczvdZP5fQWxPOTOg4tHw5mAh1ylghAJPiyiay9n+OWbdnsbyz3yxbIp1IAgmc2kdDuetdBjzg37N7ShTbhcn4mHedzzMzpHJfu0FRhwlpp90bSCQB4gDSssY5EEmVOxrlOP4om+4mVUwByHXTrM1OwXHosG065o1U6SJ/T/AD1oNfF00nx/Q1RsutT7uLLkz6DwqG1RUrgzw50JBXKwG5VmVWA/pJrsuP5AwCLl0gk6FjuGK8iVjpXK+zWGzXAYJHQCc0axHoKmmSxk6kzPnzrNm1048iTh7YILR+/nyqPdtSPl5x4DXnU3Dafl/npXptfv9/nWsNQMPejRlnprrPLb1rHErBGwPh8Z/fhW+5ZHr8P2f71g4J0PLn/63FZvLc6OyNzv2jlvjWBoLgH/AH/nVpwf21ZTF3uOO7MSGAEZLgPvDz16EVTCQRrr59Nef615jkW+JOl37wAhh0Pj4+FWVm8/jvcdxXDXcOzYdvo19O/2afyb2oJEL3cx3EgGRGtctex4Yy6FWPvPaORj4kDQn4edcmtx7ZgEirXg1trzSSQi+80+uUeJ+Q1queR1q8CLoGXE2b6uMyi6oVxqdCHCgnQ69p00qvxPCrlsgtYZQdmtl48iUm2P9xrd9JiABAGgHQbRRcWRzqsob4gkFWusY+zdVLsf0qWis8KHT6yyVT8dq7cw5nyeEn01qWcax3k+ZP6GvbWLA27v+lbfzzIZoLex7W8RKhV4lZtgbi4+BNzyzxDDxma13sdxC773E2/pxuEtr/0ro/KtvCuLZCD2zj+m3/4iurwj2rgLPigo6tYw+njJXT1oPn13BXWJ7XH2mH4uKKx+AJrLB+y1lwWVLWIg6shxV0T4/R1muixGK4VbuFbV25dukyexw+GUTvq9y1Hqs1TYr28xF36uw18xsM/aNHLS1bRV+BqBZuWsMNMBg38GwuKZvX6TfX8q18f402LREuWMNYtpt2Nvs51BykBmkSoMAjaoF3D4y5q4YT/9jx8lzfOtbcJfZnAH4V1+LH9Koi38bllLZCKNJVdT4idF+dMJjjmDLmLrBEuxIgzJKwJnWT0qFxXCZVuEEkq6rv72cGCRty5CrPhXBn7JybNyEjtmUmezeMrBQNgVafe5aaUFo3ElKsL1xrMGAcha2X1OV3QnIW5NBnfbWqzCYxmvoVudzMAVbLOUzrIkEDTWenpdcA4S9q5Nu7Zv2riaKy5rdyyxYMLoMBYKkAIS2aDoM0XS4fA4XslOGsdoW7gId3Ytps7HMuu5AC9edBz+OtgyCNP3qOhqApD3Ft3LiWmRO7eJuDOM3dBFsghhJBbYBRIiIueOZFchEyAy0AyupJIX7oGnd2EiK47ifHcpi0e8NM45eXjQdMuAu5zfYpiLeUK7i5buWQisDNxoTLEanvGJmoN25bt2y6kFRmOaILawM4GzGQIO2lcda4ldVg4c5gZDHVh5E6j0rXicUz+9HWAIGvlUGu6+Yknckn4ma8U1jSg2k9KTNYA15QXWFbs4ykg5SNNIB/U1Kwy89Krg0n97VaYbekb1ZYdNJNbin5Tv8/Ksba/vz5VsuNvsD4eh5DTfryqoi3EGutYBBzry5cE6+Pp6c6gtiJMf+hyoqabCmNR8RWnEYMrvoP2edacK5ZgOkz6Sf+6rftw2jfvQ+P78KljU69Un/DDdZUXdjz+yObeQGp8qtr1pbSi3b91fiTzY+J/sNq6zhvs41nDm6wIe6AQDutvQjTkW38stc9jsMdSRSM93aq+0p2lY3FrHA4O7fudnZtm428DYD7zE6Ko6kxVYZtiIrZhbFy6MyL3Nu0bRJ8/teSgnwq6s8As2BN4jEXemvYp6aG6fFoX8J3rRcxd3EvksjOR3S50toOg5aclFBGa0llSxJuN4yFn8Kgy3mT/TXN8U4pcdgCdthyHko0HpFfTcP7ErbwmKxF4tcdLFxgTIAYISuVQdg0HWa4/6GtvCiy9ntcVevK9uN8gtCJYHRS1xtPwnbegq7eGZ7ylmVmMd05YmNREFSRtzr6bh7r2DaR0trYvKotlFylbhOXK4AC6sQNIiRvXJWvZ7EtaHfsIVMqotISDBKg3chcElXHeO6kbxVvhr164+Gw+JJR7JOUqQbdy2WGvXOsBgfuzIUxMFpxAGKpLq10+Pt71RXrVBUcRwq5S+gOZSSTA00GbkACRr59dOp9muOjDm66qLZK9lcVtQLjCLRjdlL5dVk97UZIZa2ziOzOcMqkc2AK7R3g2hEaEHcV5w2zg8WHCnsmCljazzbQoRrh23Nti5hGnJL8iCaMxwm+LNxsPd+vZjke5BzpJ0VmkIXgMpOwKg5dxz3sPw52u3sRezdpbPZ9+c4uEHMWzaghQV16t0rtsdxBbQuXH9y2Gdh1g6KPFmIUeJFfO+EXMT2zYtmCC4S1wv7txWOYgLuV6HQCBBkVBY+3V/LaOsFjA8RoT6QK+f1be0fFe3uyJyLov9/WqmgUpSgUpSgV7XlKCxwwq3wxjWquyKsMO8f3mqq1t3P35/vyrC82p/f72rQLpj9/vrWl7v7n470VjiLvhpG/TxqGHmvMRc1Ov78/SvMFh3uutq2JZtPACNSeigCT4UrUnqbwcyTrETrJHIaT8P10rsv4eez303HDOJs2QLl0HmSZt2j4FgZ6hG2kVWcPsYZsDctqxzpczdpGqmAoug87UwhAkgE6azX2D+GXCvouBTP/OvfXXesvGVD/pTKI65qxLq9+LbjWBDzXzj2g4PBMeI/wA19Wv3BBk6b6/Gqi3wlcQ2Zx9SPs87nQHonhz8t9OT5XwP2GuYo52JtYcbv9pvC2Dv4sdPPar/AIzew+DsG1ZVbVse9rJY/edt3bzrsfaXFratEmFRR5AAbAD+1fDsd7RYe/iM+IY9ihlbSCS5G2bl8aovvZ32ZxHE2zQ1rDTvsz+vJfmfnX1vhHspYwqABRAGmmnoK+Vn+N/ZKEw2DUKBAztHyUH865rjX8XOIYiRNu2vRFP6nWoPu2OxtnKyNlZGBVk5FWEEfCvl3EuHouIIAzhVCpmIOZYClCCI1CKusSbkiCBXzZvavFky14nwIEfACrB/bq8UyGxhYmZWyFeeuZCDNB3YxGshpO4cydDlOfTvEGbdzQkEG5sQajXsaqm3cPuoweFUEkFGQAEakgMU5SLSz1rhm9sLxB7lvXfRiv2vslo+23xqK3tTiijJ20KxzNCoCT4tlzH40Hc8R9tw0i3h7n9ZVfyzVz+K9orrbtbtD4t8/wC1clcxDN7zMfMmtVB0N7ilmZbtL7fiML6dPhUe77RXCwyhUVdlUaQRB1PhzFU1KDpbntc5GUgMvdkMATKjTUROuokdOgqp4jxe5e95jl6f36+tQKUClKUClKUClKUClKUFpaqUr1EStmeipbXK1Xrnyn/NajcrUz6VVe3OZ9an8ElVuvqpa3kU665mAaANToN9t99qh8PtB7gDe7Mka+6up2112Ec2qwS7ILkQGMx0Ue6NOX6Vm++N/HqRiMULYtqkGCsA7QCCNNjOh9KveG+32KsNq3aLOoOh+NcPiMXmuBjrBBiehmKmsyufq2BnZTofnv6VWOvp974RxdsXZt3WU20fZDqSAYLNGm+w6a+A64XQqdAB5V8/wmOs4ZLFtrttFtoElnUCAAJMnwqg/ib/ABJtdicLg7gdnEPcTVQv3VbYk+EijLnP4pe2n0i4bNlvqlMSPtH7x8Onx6V83r1mnU15QKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQWM14WrUXrWz0VvZzWIetOatuH95Z6z8Nf0osSsOSsluakRzAMb/ANq8xN6ABtO/6Vh20ksdyZ/t+/Gor3JM1C16zVpdqyJrXVSlKUohSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKDYWrGa9pQeA1mGivaUGLvWM0pQeE15SlApSlApSlApSlApSlApSlApSlAr2a8pQe15SlApSlApSlApSlApSlB/9k=" alt="watch">
                        <div class="caption">
                            <h3>Faber Luba #111</h3>
                            <p>Price: Rs.18,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(8))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=8">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                
            </div>
             <div class="row">
                <div class="column-style col-md-3 col-sm-6">
                    <div class="thumbnail ">
                        <img class="img-responsive item"  src="http://images.deccanchronicle.com/dc-Cover-u560otisruufjlejhemu2glta4-20170416151918.Medi.jpeg" alt="camera">
                        <div class="caption">
                            <h3>Nokia 9</h3>
                            <p>Price: Rs.40,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(9))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=9">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item"  src="https://image01.oneplus.net/shop/201706/20/964/3a74c634fa4e301594aa0bda61625a98.jpg" alt="camera">
                        <div class="caption">
                            <h3>OnePlus 5</h3>
                            <p>Price: Rs.30,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(10))
                                  {
                                      ?>
                                 <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=10">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://i1.wp.com/www.xiaomimi6phone.com/wp-content/uploads/2017/01/Xiaomi-Redmi-Note-5.jpg" alt="camera">
                        <div class="caption">
                            <h3>Redmi Note 5</h3>
                            <p>Price: Rs.20,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(11))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=11">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>   
                    </div>
                </div>
                <div class="column-style col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img class="img-responsive item" src="https://boygeniusreport.files.wordpress.com/2017/06/google-pixel-2-concept.jpg?quality=98&strip=all" alt="camera">
                        <div class="caption">
                            <h3>Google pixel 2</h3>
                            <p>Price: Rs.60,000.00
                        </div>
                    <?php
                              if(!isset($_SESSION['email']))
                              {
                                  ?>
                                 <a class="btn btn-primary" style="width:100%;" href="login.php">Buy now</a>
                                  <?php
                              }
                              else
                              {
                                  if(check_if_added_to_cart(12))
                                  {
                                      ?>
                                    <button class="btn btn-danger disabled" style="width:100%;">Add to cart</button>
                                    <?php
                                  }
                                  else
                                  {
                                      ?>
                                    <a class="btn btn-primary" style="width:100%;" href="cart-add.php?id=12">Add to cart</a>
                                    <?php
                                  }
                              }
                            ?>      
                    </div>
                </div>
                
            </div>
            
        </div>
        <!--footer-->
        
        <?php
         include 'footer.php';
        ?>
        
    </body>
</html>

