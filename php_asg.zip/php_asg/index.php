<?php
  include 'common.php';
  if(isset($_SESSION['email']))
  {
      header('location:product.php');
  }
?>
<!DOCTYPE html>

<html>
    <head>
        <title>Lifestyle Store</title>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="asg2_style.css" type="text/css">
        
        <meta charset="UTF-8">
        <meta name="keywords" content="shopping,clothes,watches,cameras,shirts,mens clothes">
        <meta name="description" content="Best Online shopping website.best fashion style clothes for gentalmens">
        <meta name="author" content="Vineeta Suthar">
        <meta http-equiv="refresh" content="50">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
         
        <!--navigation bar-->
        
       <?php
       include 'header.php';
       ?>
        
        <!--backgrpound image-->
            <div id="bkg_img">
                <div class="container-fluid">
                    <center>
                <div id="content">
                    <h1>We sell lifestyle.</h1>
                    <p> Elat 40% OFF on premium brands.</p>
                    <a href="product.php" class="btn btn-danger" >Shop Now</a>
                </div>
                    </center>
                </div>
            </div>
        
        <!-- footer-->
        <?php
       include 'footer.php';
        ?>
    </body>
</html>
