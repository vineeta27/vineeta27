<?php

include 'common.php';
if(!isset($_SESSION['email']))
 {
       header('location:index.php');
 }
/*$regex_email="/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
if(!preg_match($regex_email,$email))
{
    echo "incorrect email";
}*/

$old_password=  mysqli_real_escape_string($con,$_POST['old_password']);
$new_password=  mysqli_real_escape_string($con,$_POST['new_password']);
$re_password=  mysqli_real_escape_string($con,$_POST['re_password']);
if($new_password!=$re_password)
{
    echo "password mis-matched";
}
else{
    $user_email=$_SESSION['email'];
    $select_query="SELECT id FROM users WHERE email='$user_email'";
    $check_query= mysqli_query($con,$select_query);
    $user1_id= mysqli_fetch_array($check_query);
    $user_id=$user1_id['id'];   
    $select_pwd_query="SELECT password FROM users WHERE id='$user_id'";
    $result_pwd_query= mysqli_query($con, $select_pwd_query);
    $pwd_result= mysqli_fetch_array($result_pwd_query);
    if($old_password==$pwd_result['password'])
    {
        $update_pwd_query="UPDATE users SET password='$new_password' WHERE id='$user_id'";
       $update_result_query = mysqli_query($con,$update_pwd_query)or die(mysqli_error($con));
       header('location:product.php');  
    }
    else{
        header('location:setting.php');
    }
}
?>

