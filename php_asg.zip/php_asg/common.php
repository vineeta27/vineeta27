<?php
$con=mysqli_connect("localhost","root","","store");
session_start();
?>