<?php
include 'common.php';
$email=  mysqli_real_escape_string($con,$_POST['email']);
$password=  mysqli_real_escape_string($con,$_POST['password']);
$select_query="select id,email from users where email='$email' AND password='$password'";
$select_query_result=mysqli_query($con,$select_query);
if(mysqli_num_rows($select_query_result)==0)
{
    echo "not registered";
}
else{
    mysqli_fetch_array($select_query_result);
    $_SESSION['email']=$email;
    $_SESSION['id']= mysqli_insert_id($con);
    header('location:product.php');
}
?>